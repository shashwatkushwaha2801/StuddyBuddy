import React, { useState } from 'react';
import { 
  Trophy, 
  Flame, 
  BookCheck, 
  School, 
  Search, 
  Crown, 
  Sparkles, 
  Filter, 
  UserPlus, 
  Check, 
  ExternalLink,
  Zap,
  Award
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useConnections } from '../../context/ConnectionsContext';
import RankBadge from '../common/RankBadge';
import StudentProfileModal from '../matching/StudentProfileModal';
import { COLLEGE_LIST } from '../../lib/mockData';

export default function LeaderboardView() {
  const { currentUser, allProfiles, claimStreakBonus } = useAuth();
  const { getConnectionStatus, sendRequest } = useConnections();

  const [selectedCollege, setSelectedCollege] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeProfileStudent, setActiveProfileStudent] = useState(null);
  const [streakClaimedFeedback, setStreakClaimedFeedback] = useState(false);

  // Sort all registered students descending by Study XP
  const sortedProfiles = [...allProfiles].sort((a, b) => (b.study_xp || 0) - (a.study_xp || 0));

  // Filter by college and search
  const filteredProfiles = sortedProfiles.filter(student => {
    const matchCollege = selectedCollege === 'all' || student.college === selectedCollege;
    const matchSearch = !searchQuery || 
      student.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.branch.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.college.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCollege && matchSearch;
  });

  const topThree = filteredProfiles.slice(0, 3);
  const remainingStudents = filteredProfiles.slice(3);

  const handleClaimStreak = () => {
    const claimed = claimStreakBonus();
    if (claimed) {
      setStreakClaimedFeedback(true);
      setTimeout(() => setStreakClaimedFeedback(false), 3000);
    }
  };

  const todayStr = new Date().toDateString();
  const isStreakClaimedToday = currentUser?.last_streak_claim === todayStr;

  return (
    <div className="space-y-6">

      {/* Header Banner & Streak Bonus Callout */}
      <div className="bg-gradient-to-r from-primary-900 via-indigo-900 to-brand-950 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden border border-primary-800/50">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 w-64 h-64 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-bold border border-amber-400/30">
              <Trophy className="w-3.5 h-3.5" />
              <span>Competitive Study Ranks</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              StudyBuddy Leaderboard
            </h1>
            <p className="text-xs sm:text-sm text-slate-300">
              Climb through Bronze, Silver, Gold, Platinum, Diamond, Heroic, and Grandmaster by completing tasks, mastering syllabus topics, and collaborating!
            </p>
          </div>

          {/* Daily Streak Card */}
          <div className="w-full md:w-auto bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-white shadow-lg animate-pulse">
                <Flame className="w-6 h-6 fill-white" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xl font-black">{currentUser?.study_streak || 0}</span>
                  <span className="text-xs text-amber-300 font-semibold">Day Streak</span>
                </div>
                <p className="text-[11px] text-slate-300">+30 XP per daily study session</p>
              </div>
            </div>

            <button
              onClick={handleClaimStreak}
              disabled={isStreakClaimedToday}
              className={`px-4 py-2 rounded-xl font-bold text-xs transition-all flex items-center gap-1.5 shadow-md ${
                isStreakClaimedToday
                  ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-400/30 cursor-default'
                  : 'bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-300 hover:to-orange-400 text-slate-950 hover:scale-105'
              }`}
            >
              {isStreakClaimedToday ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Claimed Today</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  <span>Claim Daily +30 XP</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        
        {/* College Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 scrollbar-none">
          <button
            onClick={() => setSelectedCollege('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              selectedCollege === 'all'
                ? 'bg-primary-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            🌍 Global Leaderboard
          </button>
          {currentUser?.college && (
            <button
              onClick={() => setSelectedCollege(currentUser.college)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                selectedCollege === currentUser.college
                  ? 'bg-primary-600 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <School className="w-3.5 h-3.5" />
              <span>My College ({currentUser.college})</span>
            </button>
          )}

          {/* College Dropdown for more */}
          <select
            value={selectedCollege}
            onChange={(e) => setSelectedCollege(e.target.value)}
            className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-50 border border-slate-200 text-slate-700 focus:outline-none focus:ring-2 focus:ring-primary-500/20"
          >
            <option value="all">All Universities</option>
            {COLLEGE_LIST.map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search student, college, branch..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 transition-all"
          />
        </div>
      </div>

      {/* Top 3 Podium (Only shown if at least 3 students match) */}
      {topThree.length >= 3 && !searchQuery && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
          
          {/* 2nd Place (Silver) */}
          <div className="order-2 md:order-1 bg-white rounded-3xl p-6 border border-slate-200/80 shadow-soft flex flex-col items-center text-center relative hover:shadow-md transition-all">
            <div className="absolute -top-3 px-3 py-0.5 rounded-full bg-slate-200 text-slate-800 text-[11px] font-extrabold border border-slate-300 shadow-xs flex items-center gap-1">
              <span>🥈 2nd Place</span>
            </div>
            <div className="relative mt-2 mb-3">
              <img
                src={topThree[1].avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${topThree[1].full_name}`}
                alt={topThree[1].full_name}
                className="w-20 h-20 rounded-2xl object-cover ring-4 ring-slate-300 shadow-md"
              />
              <span className="absolute -bottom-2 -right-2 w-7 h-7 rounded-full bg-slate-100 text-slate-700 font-black text-xs flex items-center justify-center border-2 border-white shadow-sm">
                2
              </span>
            </div>
            <h3 className="font-extrabold text-slate-900 text-base">{topThree[1].full_name}</h3>
            <p className="text-xs text-slate-500 font-medium">{topThree[1].college}</p>
            <div className="mt-2">
              <RankBadge xp={topThree[1].study_xp} size="sm" variant="badge" />
            </div>
            <div className="mt-4 w-full grid grid-cols-2 gap-2 pt-3 border-t border-slate-100 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px]">Study XP</span>
                <span className="font-extrabold text-primary-600">{topThree[1].study_xp?.toLocaleString()} XP</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Streak</span>
                <span className="font-bold text-amber-600 flex items-center justify-center gap-0.5">
                  <Flame className="w-3.5 h-3.5 fill-amber-500" /> {topThree[1].study_streak || 0}d
                </span>
              </div>
            </div>
            <button
              onClick={() => setActiveProfileStudent(topThree[1])}
              className="mt-4 w-full py-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 font-semibold text-xs transition-colors"
            >
              View Profile
            </button>
          </div>

          {/* 1st Place (Gold / Champion) */}
          <div className="order-1 md:order-2 bg-gradient-to-b from-amber-500/10 via-amber-500/5 to-white rounded-3xl p-6 border-2 border-amber-300 shadow-lg flex flex-col items-center text-center relative md:-translate-y-2 hover:shadow-xl transition-all">
            <div className="absolute -top-3.5 px-4 py-1 rounded-full bg-gradient-to-r from-amber-400 to-yellow-500 text-amber-950 text-xs font-black shadow-md flex items-center gap-1.5 animate-pulse">
              <Crown className="w-3.5 h-3.5 fill-amber-950" />
              <span>👑 #1 RANK CHAMPION</span>
            </div>
            <div className="relative mt-2 mb-3">
              <img
                src={topThree[0].avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${topThree[0].full_name}`}
                alt={topThree[0].full_name}
                className="w-24 h-24 rounded-2xl object-cover ring-4 ring-amber-400 shadow-xl"
              />
              <span className="absolute -bottom-2.5 -right-2.5 w-8 h-8 rounded-full bg-amber-400 text-amber-950 font-black text-sm flex items-center justify-center border-2 border-white shadow-md">
                1
              </span>
            </div>
            <h3 className="font-extrabold text-slate-900 text-lg">{topThree[0].full_name}</h3>
            <p className="text-xs text-slate-600 font-semibold">{topThree[0].college}</p>
            <div className="mt-2">
              <RankBadge xp={topThree[0].study_xp} size="md" variant="badge" />
            </div>
            <div className="mt-4 w-full grid grid-cols-2 gap-2 pt-3 border-t border-amber-100 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px]">Total XP</span>
                <span className="font-black text-amber-700 text-sm">{topThree[0].study_xp?.toLocaleString()} XP</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Streak</span>
                <span className="font-black text-rose-600 text-sm flex items-center justify-center gap-0.5">
                  <Flame className="w-4 h-4 fill-rose-500" /> {topThree[0].study_streak || 0}d
                </span>
              </div>
            </div>
            <button
              onClick={() => setActiveProfileStudent(topThree[0])}
              className="mt-4 w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-500 hover:to-yellow-600 text-amber-950 font-bold text-xs shadow-sm transition-all"
            >
              View Champion Profile
            </button>
          </div>

          {/* 3rd Place (Bronze) */}
          <div className="order-3 md:order-3 bg-white rounded-3xl p-6 border border-slate-200/80 shadow-soft flex flex-col items-center text-center relative hover:shadow-md transition-all">
            <div className="absolute -top-3 px-3 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[11px] font-extrabold border border-amber-200 shadow-xs flex items-center gap-1">
              <span>🥉 3rd Place</span>
            </div>
            <div className="relative mt-2 mb-3">
              <img
                src={topThree[2].avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${topThree[2].full_name}`}
                alt={topThree[2].full_name}
                className="w-20 h-20 rounded-2xl object-cover ring-4 ring-amber-600/40 shadow-md"
              />
              <span className="absolute -bottom-2 -right-2 w-7 h-7 rounded-full bg-amber-100 text-amber-900 font-black text-xs flex items-center justify-center border-2 border-white shadow-sm">
                3
              </span>
            </div>
            <h3 className="font-extrabold text-slate-900 text-base">{topThree[2].full_name}</h3>
            <p className="text-xs text-slate-500 font-medium">{topThree[2].college}</p>
            <div className="mt-2">
              <RankBadge xp={topThree[2].study_xp} size="sm" variant="badge" />
            </div>
            <div className="mt-4 w-full grid grid-cols-2 gap-2 pt-3 border-t border-slate-100 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px]">Study XP</span>
                <span className="font-extrabold text-primary-600">{topThree[2].study_xp?.toLocaleString()} XP</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Streak</span>
                <span className="font-bold text-amber-600 flex items-center justify-center gap-0.5">
                  <Flame className="w-3.5 h-3.5 fill-amber-500" /> {topThree[2].study_streak || 0}d
                </span>
              </div>
            </div>
            <button
              onClick={() => setActiveProfileStudent(topThree[2])}
              className="mt-4 w-full py-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 font-semibold text-xs transition-colors"
            >
              View Profile
            </button>
          </div>

        </div>
      )}

      {/* Leaderboard Table */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-soft overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-500" />
            <h2 className="font-bold text-sm text-slate-800">
              Rankings ({filteredProfiles.length} Students)
            </h2>
          </div>
          <span className="text-xs text-slate-400 font-medium">
            Live Rank Points & XP
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 text-[11px] font-bold text-slate-500 uppercase tracking-wider border-b border-slate-100">
                <th className="py-3 px-4 text-center w-16"># Rank</th>
                <th className="py-3 px-4">Student</th>
                <th className="py-3 px-4">Rank Tier</th>
                <th className="py-3 px-4 text-right">Study XP</th>
                <th className="py-3 px-4 text-center">Streak</th>
                <th className="py-3 px-4 text-center">Topics</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredProfiles.map((student, index) => {
                const isYou = student.id === currentUser?.id;
                const connStatus = getConnectionStatus(student.id);

                return (
                  <tr 
                    key={student.id} 
                    className={`transition-colors ${
                      isYou 
                        ? 'bg-primary-50/50 hover:bg-primary-50 font-medium' 
                        : 'hover:bg-slate-50/80'
                    }`}
                  >
                    {/* Rank Position */}
                    <td className="py-3.5 px-4 text-center">
                      {index === 0 ? (
                        <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-amber-400 text-amber-950 font-black text-xs shadow-sm">
                          1
                        </span>
                      ) : index === 1 ? (
                        <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-slate-300 text-slate-800 font-bold text-xs shadow-sm">
                          2
                        </span>
                      ) : index === 2 ? (
                        <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-amber-200 text-amber-900 font-bold text-xs shadow-sm">
                          3
                        </span>
                      ) : (
                        <span className="font-bold text-slate-500 text-xs">
                          #{index + 1}
                        </span>
                      )}
                    </td>

                    {/* Student Info */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={student.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${student.full_name}`}
                          alt={student.full_name}
                          className="w-10 h-10 rounded-xl object-cover ring-2 ring-slate-100 flex-shrink-0"
                        />
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-slate-900 truncate">{student.full_name}</span>
                            {isYou && (
                              <span className="px-1.5 py-0.2 rounded-md bg-primary-600 text-white text-[10px] font-bold">
                                You
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-500 truncate">
                            {student.branch} • {student.college}
                          </p>
                        </div>
                      </div>
                    </td>

                    {/* Rank Badge */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <RankBadge xp={student.study_xp || 0} size="sm" variant="badge" />
                    </td>

                    {/* Study XP */}
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <span className="font-extrabold text-slate-900">
                        {(student.study_xp || 0).toLocaleString()}
                      </span>
                      <span className="text-[10px] text-slate-400 ml-1">XP</span>
                    </td>

                    {/* Streak */}
                    <td className="py-3.5 px-4 text-center whitespace-nowrap">
                      <span className="inline-flex items-center gap-1 font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                        <Flame className="w-3.5 h-3.5 fill-amber-500" />
                        {student.study_streak || 0}d
                      </span>
                    </td>

                    {/* Topics completed */}
                    <td className="py-3.5 px-4 text-center whitespace-nowrap">
                      <span className="inline-flex items-center gap-1 font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-full">
                        <BookCheck className="w-3 h-3 text-slate-500" />
                        {student.topics_completed || 0}
                      </span>
                    </td>

                    {/* Action */}
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setActiveProfileStudent(student)}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-[11px] transition-colors"
                        >
                          Profile
                        </button>
                        {!isYou && (
                          <button
                            onClick={() => sendRequest(student.id)}
                            disabled={connStatus !== 'none'}
                            className={`p-1.5 rounded-lg text-[11px] font-semibold transition-all ${
                              connStatus === 'accepted'
                                ? 'bg-emerald-50 text-emerald-600'
                                : connStatus === 'pending_sent'
                                ? 'bg-amber-50 text-amber-600'
                                : 'bg-primary-50 text-primary-600 hover:bg-primary-100'
                            }`}
                            title={
                              connStatus === 'accepted'
                                ? 'Connected'
                                : connStatus === 'pending_sent'
                                ? 'Request Sent'
                                : 'Send Connection Request'
                            }
                          >
                            {connStatus === 'accepted' ? (
                              <Check className="w-3.5 h-3.5" />
                            ) : (
                              <UserPlus className="w-3.5 h-3.5" />
                            )}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Student Profile Preview Modal */}
      {activeProfileStudent && (
        <StudentProfileModal
          student={activeProfileStudent}
          onClose={() => setActiveProfileStudent(null)}
        />
      )}

    </div>
  );
}
