import React, { useState } from 'react';
import { 
  User, 
  School, 
  BookOpen, 
  Calendar, 
  Clock, 
  Target, 
  Award, 
  Edit3, 
  Sparkles, 
  CheckCircle2, 
  Users, 
  UserCheck, 
  Mail,
  ShieldCheck,
  Flame,
  Trophy,
  Zap,
  TrendingUp,
  History,
  BookCheck
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useConnections } from '../../context/ConnectionsContext';
import { useGroups } from '../../context/GroupsContext';
import { useTasks } from '../../context/TasksContext';
import EditProfileModal from './EditProfileModal';
import RankBadge from '../common/RankBadge';
import { getRankFromXP } from '../../lib/rankSystem';

export default function ProfileView() {
  const { currentUser, xpLogs, claimStreakBonus } = useAuth();
  const { acceptedConnections } = useConnections();
  const { groups, isMember } = useGroups();
  const { metrics } = useTasks();

  const [editModalOpen, setEditModalOpen] = useState(false);

  if (!currentUser) {
    return (
      <div className="bg-white rounded-3xl p-12 text-center border border-slate-200/80 shadow-soft">
        <User className="w-12 h-12 text-slate-300 mx-auto mb-3" />
        <h2 className="text-lg font-bold text-slate-800">Please Sign In</h2>
        <p className="text-xs text-slate-500 mt-1">Sign in or register to view and customize your student profile.</p>
      </div>
    );
  }

  const myJoinedGroups = groups.filter(g => isMember(g.id));
  const rank = getRankFromXP(currentUser.study_xp || 0);

  return (
    <div className="space-y-6">
      
      {/* Top Profile Card */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-soft overflow-hidden">
        
        {/* Banner Graphic with Rank Gradient Tone */}
        <div className={`h-40 bg-gradient-to-r ${rank.theme.bgBadge} relative overflow-hidden`}>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_20%,rgba(255,255,255,0.25),transparent_60%)]" />
          <div className="absolute top-4 right-4 flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-white text-xs font-semibold flex items-center gap-1 border border-white/20 shadow-sm">
              <ShieldCheck className="w-3.5 h-3.5" /> Verified Student
            </span>
          </div>
        </div>

        {/* Profile Info Bar */}
        <div className="px-6 sm:px-8 pb-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between -mt-16 mb-4 gap-4">
            <div className="relative">
              <img
                src={currentUser.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentUser.full_name}`}
                alt={currentUser.full_name}
                className="w-32 h-32 rounded-3xl object-cover border-4 border-white shadow-xl bg-white"
              />
              <span className="absolute bottom-1 right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-white shadow-sm" title="Online"></span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setEditModalOpen(true)}
                className="px-5 py-2.5 rounded-2xl bg-primary-600 hover:bg-primary-700 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-md shadow-primary-500/20 transition-all hover:scale-[1.02] flex-shrink-0"
              >
                <Edit3 className="w-4 h-4" />
                <span>Edit Profile</span>
              </button>
            </div>
          </div>

          <div>
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                {currentUser.full_name}
              </h1>
              <RankBadge xp={currentUser.study_xp || 0} size="md" variant="badge" />
            </div>
            
            <div className="flex flex-wrap items-center gap-y-1 gap-x-3 text-xs text-slate-600 mt-2">
              <span className="flex items-center gap-1 font-semibold text-slate-800">
                <School className="w-3.5 h-3.5 text-primary-600" />
                {currentUser.college}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1 font-medium">
                <BookOpen className="w-3.5 h-3.5 text-slate-400" />
                {currentUser.branch}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1 font-medium text-slate-500">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                {currentUser.year}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1 text-slate-400">
                <Mail className="w-3.5 h-3.5" />
                {currentUser.email}
              </span>
            </div>

            {currentUser.bio && (
              <p className="text-xs text-slate-600 mt-3.5 leading-relaxed max-w-3xl italic bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
                "{currentUser.bio}"
              </p>
            )}
          </div>

          {/* Gamified Rank Progress Card (Section 10 Requirement) */}
          <div className="mt-6 p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-primary-950 to-slate-900 text-white shadow-md border border-slate-800">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-3">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-xl ${rank.theme.bgBadge} flex items-center justify-center text-white shadow-md flex-shrink-0`}>
                  <Trophy className="w-6 h-6 text-yellow-300" />
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                    Current Competitive Rank
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-black tracking-tight text-white">{rank.fullName}</span>
                    <span className="text-xs px-2 py-0.5 rounded-md bg-white/10 text-primary-300 font-bold">
                      {(currentUser.study_xp || 0).toLocaleString()} XP
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4 text-xs">
                <div className="text-right sm:text-right">
                  <span className="text-slate-400 text-[11px] block">Next Promotion</span>
                  <span className="font-bold text-amber-300">
                    {rank.isMaxRank ? 'Peak Rank (Grandmaster)' : `${rank.nextRank?.fullName} (${rank.xpNeededForNext} XP left)`}
                  </span>
                </div>
              </div>
            </div>

            {/* Rank Progress Bar */}
            <div className="space-y-1.5">
              <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden p-0.5">
                <div 
                  className={`h-full ${rank.theme.bgBadge} rounded-full transition-all duration-700 shadow-sm`}
                  style={{ width: `${rank.isMaxRank ? 100 : rank.progressPercent}%` }}
                />
              </div>
              <div className="flex justify-between text-[10px] text-slate-400 font-medium">
                <span>{rank.minXP} XP ({rank.fullName} floor)</span>
                <span>{rank.isMaxRank ? '100% Mastered' : `${rank.progressPercent}% to next rank`}</span>
                <span>{rank.isMaxRank ? '∞' : `${rank.nextRank?.minXP} XP`}</span>
              </div>
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-100">
            <div className="p-3.5 rounded-2xl bg-amber-50/70 border border-amber-100">
              <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider block mb-1 flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-amber-600 fill-amber-500" />
                Study Streak
              </span>
              <span className="text-2xl font-black text-amber-900">{currentUser.study_streak || 0} Days</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-purple-50/70 border border-purple-100">
              <span className="text-[10px] font-bold text-purple-800 uppercase tracking-wider block mb-1 flex items-center gap-1">
                <BookCheck className="w-3.5 h-3.5 text-purple-600" />
                Topics Mastered
              </span>
              <span className="text-2xl font-black text-purple-900">{currentUser.topics_completed || 0}</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-blue-50/70 border border-blue-100">
              <span className="text-[10px] font-bold text-blue-800 uppercase tracking-wider block mb-1 flex items-center gap-1">
                <UserCheck className="w-3.5 h-3.5 text-blue-600" />
                Study Partners
              </span>
              <span className="text-2xl font-black text-blue-900">{acceptedConnections.length}</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-100">
              <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block mb-1 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Tasks Completed
              </span>
              <span className="text-2xl font-black text-emerald-900">{metrics.completed}</span>
            </div>
          </div>

        </div>
      </div>

      {/* Academic Preferences Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        
        {/* Left: Subjects & Skill Level */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-soft space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-primary-600" />
              Subjects of Interest
            </h3>
            <span className="text-[10px] font-bold text-primary-700 bg-primary-50 px-2 py-0.5 rounded-md border border-primary-100">
              50% Match Weight
            </span>
          </div>

          <div className="flex flex-wrap gap-2">
            {(currentUser.subjects || []).length > 0 ? (
              currentUser.subjects.map(sub => (
                <span
                  key={sub}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-primary-50 text-primary-700 border border-primary-200/80 shadow-2xs"
                >
                  ✓ {sub}
                </span>
              ))
            ) : (
              <p className="text-xs text-slate-400 italic">No subjects added yet. Click edit profile to add subjects.</p>
            )}
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
              <Award className="w-4 h-4 text-amber-500" />
              Self-Assessed Skill Level:
            </span>
            <span className="px-2.5 py-1 rounded-xl text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
              {currentUser.skill_level || 'Intermediate'}
            </span>
          </div>
        </div>

        {/* Right: Study Timings & Goals */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-soft space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-600" />
              Preferred Study Timing
            </h3>
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100">
              25% Match Weight
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs font-semibold text-slate-800 flex items-center justify-between">
            <span>{currentUser.study_timing || 'Flexible Hours'}</span>
            <span className="text-[11px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
              Active Time Slot
            </span>
          </div>

          <div className="pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Target className="w-4 h-4 text-purple-600" />
                Learning Goals:
              </span>
              <span className="text-[10px] font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md border border-purple-100">
                25% Match Weight
              </span>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {(currentUser.learning_goals || []).map(goal => (
                <span
                  key={goal}
                  className="px-2.5 py-1 rounded-xl text-xs font-medium bg-purple-50 text-purple-700 border border-purple-100"
                >
                  🎯 {goal}
                </span>
              ))}
            </div>
          </div>
        </div>

      </div>

      {/* Recent XP Activity Log */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-soft">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-primary-600" />
            <h3 className="text-sm font-bold text-slate-900">Study XP Activity & Milestones</h3>
          </div>
          <span className="text-xs text-slate-400 font-medium">Automatic Anti-Cheat XP Auditing</span>
        </div>

        <div className="space-y-2.5">
          {xpLogs && xpLogs.length > 0 ? (
            xpLogs.slice(0, 5).map(log => (
              <div 
                key={log.id} 
                className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs ${
                    log.type === 'gain' 
                      ? 'bg-emerald-100 text-emerald-700' 
                      : 'bg-rose-100 text-rose-700'
                  }`}>
                    {log.type === 'gain' ? '+' : '-'}
                  </div>
                  <div>
                    <span className="font-bold text-slate-800 block">{log.action}</span>
                    <span className="text-[11px] text-slate-500">{log.reason}</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className={`font-black ${log.type === 'gain' ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {log.type === 'gain' ? `+${log.amount} XP` : `-${log.amount} XP`}
                  </span>
                  <span className="text-[10px] text-slate-400 block">
                    {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            ))
          ) : (
            <p className="text-xs text-slate-400 italic text-center py-4">No recent activity recorded.</p>
          )}
        </div>
      </div>

      {/* Edit Profile Modal */}
      {editModalOpen && (
        <EditProfileModal
          onClose={() => setEditModalOpen(false)}
        />
      )}

    </div>
  );
}
