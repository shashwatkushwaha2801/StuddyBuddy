import React, { useState } from 'react';
import { 
  X, 
  User, 
  School, 
  BookOpen, 
  Calendar, 
  Clock, 
  Target, 
  Award, 
  Image, 
  Check, 
  Sparkles 
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { AVAILABLE_SUBJECTS, STUDY_TIMINGS, LEARNING_GOALS, SKILL_LEVELS, COLLEGE_LIST } from '../../lib/mockData';

export default function EditProfileModal({ onClose }) {
  const { currentUser, updateProfile } = useAuth();

  const [fullName, setFullName] = useState(currentUser?.full_name || '');
  const [avatarUrl, setAvatarUrl] = useState(currentUser?.avatar_url || '');
  const [college, setCollege] = useState(currentUser?.college || '');
  const [branch, setBranch] = useState(currentUser?.branch || '');
  const [year, setYear] = useState(currentUser?.year || '1st Year');
  const [skillLevel, setSkillLevel] = useState(currentUser?.skill_level || 'Intermediate');
  const [studyTiming, setStudyTiming] = useState(currentUser?.study_timing || 'Evening (5PM - 9PM)');
  const [bio, setBio] = useState(currentUser?.bio || '');
  const [subjects, setSubjects] = useState(currentUser?.subjects || []);
  const [goals, setGoals] = useState(currentUser?.learning_goals || []);

  const toggleSubject = (sub) => {
    setSubjects(prev =>
      prev.includes(sub) ? prev.filter(s => s !== sub) : [...prev, sub]
    );
  };

  const toggleGoal = (g) => {
    setGoals(prev =>
      prev.includes(g) ? prev.filter(item => item !== g) : [...prev, g]
    );
  };

  const handlePresetAvatar = (seed) => {
    setAvatarUrl(`https://api.dicebear.com/7.x/avataaars/svg?seed=${seed}`);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    updateProfile({
      full_name: fullName,
      avatar_url: avatarUrl,
      college,
      branch,
      year,
      skill_level: skillLevel,
      study_timing: studyTiming,
      bio,
      subjects,
      learning_goals: goals
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6 animate-scale-in">
        
        {/* Header */}
        <div className="p-6 pb-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-primary-50 text-primary-600 flex items-center justify-center">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Edit Student Profile</h2>
              <p className="text-xs text-slate-500">Update academic focus and preferences</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          
          {/* Avatar Preview & Quick Presets */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-2">Profile Picture</label>
            <div className="flex items-center gap-3 mb-2">
              <img
                src={avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${fullName}`}
                alt="Avatar"
                className="w-14 h-14 rounded-2xl object-cover border-2 border-primary-500/30"
              />
              <div className="flex-1">
                <input
                  type="url"
                  value={avatarUrl}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                  placeholder="Paste custom image URL..."
                  className="w-full px-3 py-1.5 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                />
                <div className="flex items-center gap-1.5 mt-1.5 text-[11px] text-slate-500">
                  <span>Presets:</span>
                  {['Felix', 'Chloe', 'Zack', 'Luna', 'Alex'].map(name => (
                    <button
                      key={name}
                      type="button"
                      onClick={() => handlePresetAvatar(name)}
                      className="px-1.5 py-0.5 rounded bg-slate-100 hover:bg-primary-50 hover:text-primary-700 transition-colors"
                    >
                      {name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Full Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">Full Name *</label>
            <input
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/20"
            />
          </div>

          {/* College & Branch */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">College Name *</label>
              <input
                type="text"
                required
                list="colleges_edit"
                value={college}
                onChange={(e) => setCollege(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-primary-500/20"
              />
              <datalist id="colleges_edit">
                {COLLEGE_LIST.map(c => <option key={c} value={c} />)}
              </datalist>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">Course / Branch *</label>
              <input
                type="text"
                required
                value={branch}
                onChange={(e) => setBranch(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-primary-500/20"
              />
            </div>
          </div>

          {/* Year & Skill Level */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">Year of Study</label>
              <select
                value={year}
                onChange={(e) => setYear(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-primary-500/20"
              >
                <option value="1st Year">1st Year (Freshman)</option>
                <option value="2nd Year">2nd Year (Sophomore)</option>
                <option value="3rd Year">3rd Year (Junior)</option>
                <option value="4th Year">4th Year (Senior)</option>
                <option value="Graduate / Masters">Graduate / Masters</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">Current Skill Level</label>
              <select
                value={skillLevel}
                onChange={(e) => setSkillLevel(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-primary-500/20"
              >
                {SKILL_LEVELS.map(lvl => (
                  <option key={lvl} value={lvl}>{lvl}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Preferred Study Timing (25% matching factor) */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Preferred Study Timing (25% Match Weight)
            </label>
            <select
              value={studyTiming}
              onChange={(e) => setStudyTiming(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-primary-500/20"
            >
              {STUDY_TIMINGS.map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          {/* Subjects of Interest (50% matching factor) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-700">
                Subjects of Interest (50% Match Weight)
              </label>
              <span className="text-[10px] text-primary-600 font-semibold">{subjects.length} selected</span>
            </div>
            <div className="flex flex-wrap gap-1 max-h-32 overflow-y-auto p-1 border border-slate-100 rounded-xl bg-slate-50/50">
              {AVAILABLE_SUBJECTS.map(sub => {
                const isSelected = subjects.includes(sub);
                return (
                  <button
                    key={sub}
                    type="button"
                    onClick={() => toggleSubject(sub)}
                    className={`px-2 py-0.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1 ${
                      isSelected
                        ? 'bg-primary-600 text-white'
                        : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {isSelected && <Check className="w-3 h-3" />}
                    <span>{sub}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Learning Goals (25% matching factor) */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Learning Goals (25% Match Weight)
            </label>
            <div className="flex flex-wrap gap-1">
              {LEARNING_GOALS.map(goal => {
                const isSelected = goals.includes(goal);
                return (
                  <button
                    key={goal}
                    type="button"
                    onClick={() => toggleGoal(goal)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all flex items-center gap-1 ${
                      isSelected
                        ? 'bg-brand-600 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {isSelected && <Check className="w-3 h-3" />}
                    <span>{goal}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Bio / Short introduction */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">Short Introduction / Bio</label>
            <textarea
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell potential study buddies about your background, habits, and what you are looking for..."
              className="w-full p-3 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-primary-500/20"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-primary-600 hover:bg-primary-700 text-white font-semibold text-sm shadow-md shadow-primary-500/20 transition-all"
            >
              Save Profile Changes
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}
