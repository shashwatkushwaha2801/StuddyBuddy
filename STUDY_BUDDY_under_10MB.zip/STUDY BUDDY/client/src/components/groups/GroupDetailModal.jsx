import React, { useState } from 'react';
import { 
  X, 
  Users, 
  Calendar, 
  BookOpen, 
  Lock, 
  Globe, 
  UserPlus, 
  LogOut, 
  MessageSquare, 
  Send, 
  Sparkles,
  School
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useGroups } from '../../context/GroupsContext';
import RankBadge from '../common/RankBadge';

export default function GroupDetailModal({ group, onClose }) {
  const { currentUser } = useAuth();
  const { joinGroup, leaveGroup, isMember, getGroupMembers } = useGroups();

  const [activeTab, setActiveTab] = useState('members'); // 'members' | 'discussion'
  const [commentText, setCommentText] = useState('');
  const [comments, setComments] = useState([
    {
      id: 'c1',
      author: group.creator_name || 'Study Leader',
      text: `Welcome to ${group.name}! We will be reviewing high-yield topics every session. Feel free to drop questions here!`,
      time: '2 hours ago'
    }
  ]);

  if (!group) return null;

  const isUserJoined = isMember(group.id);
  const members = getGroupMembers(group.id);

  const handlePostComment = (e) => {
    e.preventDefault();
    if (!commentText.trim() || !currentUser) return;
    const newComment = {
      id: `c_${Date.now()}`,
      author: currentUser.full_name,
      text: commentText.trim(),
      time: 'Just now'
    };
    setComments(prev => [...prev, newComment]);
    setCommentText('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6 flex flex-col h-[600px] animate-scale-in">
        
        {/* Header */}
        <div className="p-6 pb-4 border-b border-slate-100 bg-white">
          <div className="flex items-start justify-between gap-3 mb-2">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2.5 py-0.5 rounded-lg text-xs font-semibold bg-primary-50 text-primary-700 border border-primary-100">
                  {group.subject}
                </span>
                <span className="flex items-center gap-1 text-[11px] text-slate-500 font-medium">
                  {group.visibility === 'public' ? (
                    <>
                      <Globe className="w-3 h-3 text-slate-400" /> Public Group
                    </>
                  ) : (
                    <>
                      <Lock className="w-3 h-3 text-amber-500" /> Private Group
                    </>
                  )}
                </span>
              </div>
              <h2 className="text-xl font-bold text-slate-900">{group.name}</h2>
            </div>

            <div className="flex items-center gap-2">
              {isUserJoined ? (
                <button
                  onClick={() => leaveGroup(group.id)}
                  className="px-3 py-1.5 rounded-xl border border-rose-200 text-rose-600 hover:bg-rose-50 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <LogOut className="w-3.5 h-3.5" /> Leave
                </button>
              ) : (
                <button
                  onClick={() => joinGroup(group.id)}
                  className="px-4 py-1.5 rounded-xl bg-primary-600 hover:bg-primary-700 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all"
                >
                  <UserPlus className="w-3.5 h-3.5" /> Join Group
                </button>
              )}

              <button
                onClick={onClose}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">
            {group.description}
          </p>

          {/* Schedule */}
          {group.schedule && (
            <div className="flex items-center gap-1.5 text-xs font-medium text-slate-600 mt-3 bg-slate-50 p-2 rounded-xl border border-slate-100">
              <Calendar className="w-3.5 h-3.5 text-primary-600" />
              <span>Schedule: <strong className="text-slate-800">{group.schedule}</strong></span>
            </div>
          )}

          {/* Tabs */}
          <div className="flex gap-2 mt-4 border-b border-slate-100 pb-1">
            <button
              onClick={() => setActiveTab('members')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors ${
                activeTab === 'members'
                  ? 'bg-slate-100 text-slate-900'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Group Members ({members.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('discussion')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors ${
                activeTab === 'discussion'
                  ? 'bg-slate-100 text-slate-900'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Discussion Board</span>
            </button>
          </div>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-50/50">
          
          {/* Members List */}
          {activeTab === 'members' && (
            <div className="space-y-2.5">
              {members.length === 0 ? (
                <p className="text-center text-xs text-slate-400 py-6">No members listed yet.</p>
              ) : (
                members.map(member => (
                  <div
                    key={member.id}
                    className="p-3 rounded-2xl bg-white border border-slate-200/80 shadow-2xs flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={member.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${member.full_name}`}
                        alt={member.full_name}
                        className="w-9 h-9 rounded-xl object-cover border border-slate-200"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h4 className="text-xs font-bold text-slate-900 truncate">{member.full_name}</h4>
                          <RankBadge xp={member.study_xp || 0} size="xs" variant="badge" />
                        </div>
                        <p className="text-[11px] text-slate-500 flex items-center gap-1 truncate mt-0.5">
                          <School className="w-3 h-3 text-slate-400" />
                          <span>{member.college}</span>
                        </p>
                      </div>
                    </div>

                    <div className="text-right flex flex-col items-end gap-1">
                      <span className="text-[10px] font-semibold text-primary-700 bg-primary-50 px-2 py-0.5 rounded-md border border-primary-100">
                        {member.branch}
                      </span>
                      <p className="text-[10px] text-slate-400">{member.year}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* Discussion Board */}
          {activeTab === 'discussion' && (
            <div className="space-y-3">
              {comments.map(c => (
                <div key={c.id} className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-slate-800">{c.author}</span>
                    <span className="text-[10px] text-slate-400">{c.time}</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">{c.text}</p>
                </div>
              ))}
            </div>
          )}

        </div>

        {/* Footer for Discussion Input */}
        {activeTab === 'discussion' && (
          <form onSubmit={handlePostComment} className="p-3 border-t border-slate-100 bg-white flex items-center gap-2">
            <input
              type="text"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder="Ask a question or share a resource..."
              className="flex-1 px-4 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 bg-slate-50"
            />
            <button
              type="submit"
              disabled={!commentText.trim()}
              className="p-2 rounded-xl bg-primary-600 hover:bg-primary-700 text-white shadow-xs transition-all disabled:opacity-40"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        )}

      </div>
    </div>
  );
}
