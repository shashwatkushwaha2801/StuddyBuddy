import React, { useState } from 'react';
import { 
  Users, 
  Plus, 
  Search, 
  Calendar, 
  BookOpen, 
  Globe, 
  Lock, 
  Check, 
  Sparkles, 
  ExternalLink,
  ArrowRight
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useGroups } from '../../context/GroupsContext';
import { AVAILABLE_SUBJECTS } from '../../lib/mockData';
import GroupDetailModal from './GroupDetailModal';
import CreateGroupModal from './CreateGroupModal';

export default function GroupsView() {
  const { currentUser } = useAuth();
  const { 
    filteredGroups, 
    filterSubject, 
    setFilterSubject, 
    searchQuery, 
    setSearchQuery, 
    joinGroup, 
    leaveGroup, 
    isMember 
  } = useGroups();

  const [selectedGroup, setSelectedGroup] = useState(null);
  const [createModalOpen, setCreateModalOpen] = useState(false);

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-soft">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary-50 text-primary-700 text-xs font-semibold mb-2 border border-primary-100">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Real Database-Backed Communities</span>
            </div>
            <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
              <Users className="w-6 h-6 text-primary-600" />
              Student Study Groups
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Join subject circles, participate in weekly co-working sessions, and collaborate with peers across campuses.
            </p>
          </div>

          <button
            onClick={() => setCreateModalOpen(true)}
            className="px-4 py-2.5 rounded-2xl bg-primary-600 hover:bg-primary-700 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-md shadow-primary-500/20 transition-all hover:scale-[1.02] flex-shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Create Study Group</span>
          </button>
        </div>

        {/* Search & Subject Tabs */}
        <div className="mt-6 space-y-3">
          <div className="relative">
            <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search study groups by title, subject, or keywords..."
              className="w-full pl-10 pr-4 py-2.5 rounded-2xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 bg-slate-50/50"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            <button
              onClick={() => setFilterSubject('all')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-all whitespace-nowrap ${
                filterSubject === 'all'
                  ? 'bg-primary-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All Subjects
            </button>
            {AVAILABLE_SUBJECTS.slice(0, 8).map(sub => (
              <button
                key={sub}
                onClick={() => setFilterSubject(sub)}
                className={`px-3 py-1.5 rounded-xl font-semibold transition-all whitespace-nowrap ${
                  filterSubject.toLowerCase() === sub.toLowerCase()
                    ? 'bg-primary-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {sub}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Groups Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredGroups.map(group => {
          const joined = isMember(group.id);
          return (
            <div
              key={group.id}
              className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-soft hover:shadow-elevated transition-all flex flex-col justify-between group"
            >
              <div>
                {/* Subject & Visibility */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="px-2.5 py-0.5 rounded-lg text-xs font-semibold bg-primary-50 text-primary-700 border border-primary-100">
                    {group.subject}
                  </span>
                  <span className="flex items-center gap-1 text-[11px] text-slate-400 font-medium">
                    {group.visibility === 'public' ? (
                      <Globe className="w-3.5 h-3.5" />
                    ) : (
                      <Lock className="w-3.5 h-3.5 text-amber-500" />
                    )}
                    <span className="capitalize">{group.visibility}</span>
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 group-hover:text-primary-600 transition-colors mb-1.5">
                  {group.name}
                </h3>

                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed mb-3">
                  {group.description}
                </p>

                {/* Schedule */}
                {group.schedule && (
                  <div className="flex items-center gap-1.5 text-xs text-slate-600 bg-slate-50 p-2 rounded-xl border border-slate-100 mb-3">
                    <Calendar className="w-3.5 h-3.5 text-primary-600 flex-shrink-0" />
                    <span className="truncate">{group.schedule}</span>
                  </div>
                )}

                {/* Member count */}
                <div className="flex items-center justify-between text-xs text-slate-500 mb-4">
                  <span className="flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-slate-400" />
                    <strong className="text-slate-800">{group.member_count || group.members?.length || 1}</strong> members
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Lead: {group.creator_name || 'Admin'}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
                <button
                  onClick={() => setSelectedGroup(group)}
                  className="flex-1 py-2 px-3 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span>View Details</span>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {joined ? (
                  <button
                    onClick={() => leaveGroup(group.id)}
                    className="py-2 px-3.5 rounded-xl bg-emerald-50 hover:bg-rose-50 border border-emerald-200 hover:border-rose-200 text-emerald-700 hover:text-rose-700 text-xs font-semibold flex items-center gap-1 transition-colors group/leave"
                  >
                    <Check className="w-3.5 h-3.5 group-hover/leave:hidden" />
                    <span className="group-hover/leave:hidden">Joined</span>
                    <span className="hidden group-hover/leave:inline">Leave</span>
                  </button>
                ) : (
                  <button
                    onClick={() => joinGroup(group.id)}
                    className="py-2 px-3.5 rounded-xl bg-primary-600 hover:bg-primary-700 text-white text-xs font-semibold shadow-xs transition-all hover:scale-[1.02]"
                  >
                    Join
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Modals */}
      {selectedGroup && (
        <GroupDetailModal
          group={selectedGroup}
          onClose={() => setSelectedGroup(null)}
        />
      )}

      {createModalOpen && (
        <CreateGroupModal
          onClose={() => setCreateModalOpen(false)}
        />
      )}

    </div>
  );
}
