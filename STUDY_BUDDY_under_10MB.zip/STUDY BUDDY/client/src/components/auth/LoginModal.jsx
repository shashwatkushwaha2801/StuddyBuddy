import React, { useState } from 'react';
import { LogIn, Mail, Lock, AlertCircle, X, Sparkles, Check } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { INITIAL_STUDENTS } from '../../lib/mockData';

export default function LoginModal() {
  const { authModalMode, setAuthModalMode, login, isSupabaseConfigured } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (authModalMode !== 'login') return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);

    const res = await login(email, password);
    setIsSubmitting(false);

    if (!res.success) {
      setError(res.error || 'Failed to login');
    }
  };

  const handleQuickDemoLogin = async (student) => {
    setEmail(student.email);
    setPassword('demo1234');
    setError('');
    await login(student.email, 'demo1234');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden animate-scale-in">
        
        {/* Header */}
        <div className="p-6 pb-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-primary-50 text-primary-600 flex items-center justify-center">
              <LogIn className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Student Login</h2>
              <p className="text-xs text-slate-500">Welcome back to StudyBuddy</p>
            </div>
          </div>
          <button
            onClick={() => setAuthModalMode(null)}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Demo Logins Bar */}
        <div className="bg-slate-50 px-6 py-3 border-b border-slate-100">
          <p className="text-xs font-semibold text-slate-700 flex items-center gap-1.5 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-primary-600" />
            1-Click Demo Logins:
          </p>
          <div className="flex flex-wrap gap-2">
            {INITIAL_STUDENTS.slice(0, 3).map(student => (
              <button
                key={student.id}
                type="button"
                onClick={() => handleQuickDemoLogin(student)}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white border border-slate-200 hover:border-primary-400 hover:bg-primary-50 text-xs font-medium text-slate-700 hover:text-primary-800 transition-all shadow-xs"
              >
                <img src={student.avatar_url} alt="" className="w-4 h-4 rounded-full object-cover" />
                <span>{student.full_name.split(' ')[0]} ({student.branch.split(' ')[0]})</span>
              </button>
            ))}
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              University Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g. alex.chen@stanford.edu"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 transition-all"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-700">Password</label>
              <button
                type="button"
                onClick={() => setAuthModalMode('forgot')}
                className="text-xs text-primary-600 hover:text-primary-700 font-medium"
              >
                Forgot password?
              </button>
            </div>
            <div className="relative">
              <Lock className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 transition-all"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-2.5 rounded-xl bg-primary-600 hover:bg-primary-700 text-white font-semibold text-sm shadow-md shadow-primary-500/20 transition-all disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {isSubmitting ? 'Signing in...' : 'Sign In'}
          </button>

          <p className="text-center text-xs text-slate-500 pt-2">
            Don't have an account?{' '}
            <button
              type="button"
              onClick={() => setAuthModalMode('register')}
              className="text-primary-600 hover:text-primary-700 font-semibold"
            >
              Register here
            </button>
          </p>
        </form>

      </div>
    </div>
  );
}
