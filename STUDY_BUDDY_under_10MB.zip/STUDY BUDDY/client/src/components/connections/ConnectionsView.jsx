import React, { useState } from 'react';
import { 
  UserCheck, 
  UserPlus, 
  Clock4, 
  MessageSquare, 
  Check, 
  X, 
  Trash2, 
  School, 
  BookOpen, 
  Calendar, 
  Clock, 
  Search, 
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useConnections } from '../../context/ConnectionsContext';
import DirectChatModal from './DirectChatModal';
import StudentProfileModal from '../matching/StudentProfileModal';
import RankBadge from '../common/RankBadge';

export default function ConnectionsView({ initialSubTab = 'connected' }) {
  const { currentUser } = useAuth();
  const { 
    receivedRequests, 
    sentRequests, 
    acceptedConnections, 
    acceptRequest, 
    rejectRequest, 
    cancelOrRemoveRequest 
  } = useConnections();

  const [activeSubTab, setActiveSubTab] = useState(initialSubTab); // 'connected' | 'received' | 'sent'
  const [searchQuery, setSearchQuery] = useState('');
  const [chatPartner, setChatPartner] = useState(null);
  const [profileStudent, setProfileStudent] = useState(null);

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-soft">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
              <UserCheck className="w-6 h-6 text-primary-600" />
              Connections Hub
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Manage study partnerships, pending invitations, and chat with your verified collaborators.
            </p>
          </div>

          {/* Quick Stats Pill */}
          <div className="flex items-center gap-2 text-xs">
            <span className="px-3 py-1.5 rounded-xl bg-primary-50 text-primary-700 font-bold border border-primary-100">
              {acceptedConnections.length} Active Partners
            </span>
            {receivedRequests.length > 0 && (
              <span className="px-3 py-1.5 rounded-xl bg-amber-50 text-amber-700 font-bold border border-amber-200 animate-pulse">
                {receivedRequests.length} Pending Invites
              </span>
            )}
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 mt-6 border-b border-slate-100 pb-2">
          
          <button
            onClick={() => setActiveSubTab('connected')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeSubTab === 'connected'
                ? 'bg-primary-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>My Study Buddies ({acceptedConnections.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('received')}
            className={`relative px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeSubTab === 'received'
                ? 'bg-primary-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            <span>Received Requests</span>
            {receivedRequests.length > 0 && (
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                activeSubTab === 'received' ? 'bg-white text-primary-700' : 'bg-primary-600 text-white'
              }`}>
                {receivedRequests.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveSubTab('sent')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeSubTab === 'sent'
                ? 'bg-primary-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Clock4 className="w-4 h-4" />
            <span>Sent ({sentRequests.length})</span>
          </button>

        </div>
      </div>

      {/* 1. My Study Buddies (Accepted Connections) */}
      {activeSubTab === 'connected' && (
        <div className="space-y-4">
          {acceptedConnections.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200/80 shadow-soft">
              <UserCheck className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-800 mb-1">No Active Study Buddies Yet</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4">
                Explore the partner recommendations tab and send connection requests to peers with shared subjects!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {acceptedConnections.map(conn => {
                const partner = conn.student;
                return (
                  <div
                    key={conn.id}
                    className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-soft hover:shadow-elevated transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-3 mb-3">
                        <img
                          src={partner.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${partner.full_name}`}
                          alt={partner.full_name}
                          className="w-12 h-12 rounded-2xl object-cover border border-slate-200"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h4 className="text-sm font-bold text-slate-900 truncate">{partner.full_name}</h4>
                            <RankBadge xp={partner.study_xp || 0} size="xs" variant="badge" />
                          </div>
                          <p className="text-[11px] text-slate-500 flex items-center gap-1 truncate mt-0.5">
                            <School className="w-3 h-3 text-slate-400" />
                            <span className="truncate">{partner.college}</span>
                          </p>
                          <p className="text-[10px] text-slate-400 mt-0.5 truncate">
                            {partner.branch} • {partner.year}
                          </p>
                        </div>
                      </div>

                      {/* Subjects */}
                      <div className="mb-3">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                          Focus Subjects:
                        </span>
                        <div className="flex flex-wrap gap-1">
                          {(partner.subjects || []).slice(0, 3).map(sub => (
                            <span
                              key={sub}
                              className="px-2 py-0.5 rounded-lg text-[11px] font-medium bg-slate-100 text-slate-700"
                            >
                              {sub}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-xs text-slate-600 bg-slate-50 p-2 rounded-xl mb-4">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Timing:</span>
                        </span>
                        <span className="font-semibold text-slate-800">{partner.study_timing || 'Flexible'}</span>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
                      <button
                        onClick={() => setChatPartner(partner)}
                        className="flex-1 py-2 px-3 rounded-xl bg-primary-600 hover:bg-primary-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs transition-all"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Chat & Coordinate</span>
                      </button>

                      <button
                        onClick={() => setProfileStudent(partner)}
                        className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-semibold"
                        title="View Full Profile"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => cancelOrRemoveRequest(conn.id)}
                        className="p-2 rounded-xl border border-rose-100 hover:bg-rose-50 text-rose-500 text-xs font-semibold transition-colors"
                        title="Disconnect"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 2. Received Requests */}
      {activeSubTab === 'received' && (
        <div className="space-y-4">
          {receivedRequests.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200/80 shadow-soft">
              <UserPlus className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-800 mb-1">No Pending Requests Received</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                When other students request to study with you, they will appear right here for your approval.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {receivedRequests.map(req => {
                const student = req.student;
                return (
                  <div
                    key={req.id}
                    className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-soft hover:shadow-elevated transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-3 mb-3">
                        <img
                          src={student.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${student.full_name}`}
                          alt={student.full_name}
                          className="w-12 h-12 rounded-2xl object-cover border border-slate-200"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h4 className="text-sm font-bold text-slate-900 truncate">{student.full_name}</h4>
                            <RankBadge xp={student.study_xp || 0} size="xs" variant="badge" />
                          </div>
                          <p className="text-[11px] text-slate-500 truncate mt-0.5">{student.college}</p>
                          <p className="text-[10px] text-slate-400 truncate">{student.branch} • {student.year}</p>
                        </div>
                      </div>

                      {req.message && (
                        <div className="p-3 rounded-2xl bg-primary-50/50 border border-primary-100 text-xs text-slate-700 italic mb-3">
                          "{req.message}"
                        </div>
                      )}

                      <div className="mb-3">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                          Subjects:
                        </span>
                        <div className="flex flex-wrap gap-1">
                          {(student.subjects || []).slice(0, 3).map(sub => (
                            <span key={sub} className="px-2 py-0.5 rounded-lg text-[11px] font-medium bg-slate-100 text-slate-700">
                              {sub}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-100 flex gap-2">
                      <button
                        onClick={() => acceptRequest(req.id)}
                        className="flex-1 py-2 px-3 rounded-xl bg-primary-600 hover:bg-primary-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-sm transition-all"
                      >
                        <Check className="w-4 h-4" />
                        <span>Accept Request</span>
                      </button>

                      <button
                        onClick={() => rejectRequest(req.id)}
                        className="py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center justify-center gap-1 transition-all"
                      >
                        <X className="w-4 h-4" />
                        <span>Decline</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 3. Sent Requests */}
      {activeSubTab === 'sent' && (
        <div className="space-y-4">
          {sentRequests.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200/80 shadow-soft">
              <Clock4 className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-800 mb-1">No Pending Sent Requests</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Invitations you send to other students will show up here until they accept or decline.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {sentRequests.map(req => {
                const student = req.student;
                return (
                  <div
                    key={req.id}
                    className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-soft flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-3 mb-3">
                        <img
                          src={student.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${student.full_name}`}
                          alt={student.full_name}
                          className="w-12 h-12 rounded-2xl object-cover border border-slate-200"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h4 className="text-sm font-bold text-slate-900 truncate">{student.full_name}</h4>
                            <RankBadge xp={student.study_xp || 0} size="xs" variant="badge" />
                          </div>
                          <p className="text-[11px] text-slate-500 truncate mt-0.5">{student.college}</p>
                          <p className="text-[10px] text-slate-400 truncate">{student.branch} • {student.year}</p>
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs flex items-center gap-2 mb-3">
                        <Clock4 className="w-3.5 h-3.5 text-amber-600 flex-shrink-0" />
                        <span>Awaiting student response...</span>
                      </div>

                      {req.message && (
                        <p className="text-xs text-slate-500 italic bg-slate-50 p-2.5 rounded-xl border border-slate-100 mb-3">
                          "{req.message}"
                        </p>
                      )}
                    </div>

                    <div className="pt-3 border-t border-slate-100">
                      <button
                        onClick={() => cancelOrRemoveRequest(req.id)}
                        className="w-full py-2 px-3 rounded-xl border border-rose-200 hover:bg-rose-50 text-rose-600 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Cancel Pending Request</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Modals */}
      {chatPartner && (
        <DirectChatModal
          partner={chatPartner}
          onClose={() => setChatPartner(null)}
        />
      )}

      {profileStudent && (
        <StudentProfileModal
          student={profileStudent}
          currentUser={currentUser}
          onClose={() => setProfileStudent(null)}
        />
      )}

    </div>
  );
}
