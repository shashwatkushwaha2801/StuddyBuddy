import React, { useState, useEffect, useRef } from 'react';
import { X, Send, School, BookOpen, Sparkles, Video, Calendar, Check } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useConnections } from '../../context/ConnectionsContext';

export default function DirectChatModal({ partner, onClose }) {
  const { currentUser } = useAuth();
  const { getChatMessages, sendMessage } = useConnections();
  const [inputText, setInputText] = useState('');
  const [sessionScheduled, setSessionScheduled] = useState(false);
  const messagesEndRef = useRef(null);

  if (!partner || !currentUser) return null;

  const messages = getChatMessages(partner.id);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = (e) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    sendMessage(partner.id, inputText);
    setInputText('');
  };

  const handleScheduleSession = () => {
    sendMessage(
      partner.id,
      `📅 Study Session scheduled! Let's meet on Google Meet / Zoom tomorrow at 7:00 PM.`
    );
    setSessionScheduled(true);
    setTimeout(() => setSessionScheduled(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col h-[560px] animate-scale-in">
        
        {/* Chat Header */}
        <div className="p-4 px-6 border-b border-slate-100 flex items-center justify-between bg-white z-10 shadow-2xs">
          <div className="flex items-center gap-3 min-w-0">
            <div className="relative">
              <img
                src={partner.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${partner.full_name}`}
                alt={partner.full_name}
                className="w-10 h-10 rounded-full object-cover border border-slate-200"
              />
              <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white"></span>
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-bold text-slate-900 truncate">{partner.full_name}</h3>
              <p className="text-[11px] text-slate-500 truncate">
                {partner.college} • {partner.branch}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleScheduleSession}
              className={`p-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                sessionScheduled 
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                  : 'bg-primary-50 text-primary-700 hover:bg-primary-100 border border-primary-200'
              }`}
              title="Schedule a study session"
            >
              {sessionScheduled ? <Check className="w-4 h-4 text-emerald-600" /> : <Video className="w-4 h-4 text-primary-600" />}
              <span className="hidden sm:inline">
                {sessionScheduled ? 'Invited!' : 'Study Session'}
              </span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Message Feed */}
        <div className="flex-1 p-6 overflow-y-auto space-y-3 bg-slate-50/50">
          
          {/* Welcome Prompt */}
          <div className="p-3 rounded-2xl bg-white border border-slate-100 text-center text-xs text-slate-500 max-w-sm mx-auto shadow-2xs">
            <Sparkles className="w-4 h-4 text-primary-600 mx-auto mb-1" />
            <p className="font-semibold text-slate-800">You are connected with {partner.full_name}!</p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Coordinate study sessions, ask questions, or share notes.
            </p>
          </div>

          {messages.map(msg => {
            const isMe = msg.sender_id === currentUser.id;
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[78%] px-4 py-2.5 rounded-2xl text-xs shadow-2xs ${
                    isMe
                      ? 'bg-primary-600 text-white rounded-br-xs'
                      : 'bg-white text-slate-800 border border-slate-200/80 rounded-bl-xs'
                  }`}
                >
                  <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                </div>
                <span className="text-[10px] text-slate-400 mt-1 px-1">
                  {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Message Input Footer */}
        <form onSubmit={handleSend} className="p-4 border-t border-slate-100 bg-white flex items-center gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={`Message ${partner.full_name.split(' ')[0]}...`}
            className="flex-1 px-4 py-2.5 rounded-2xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 transition-all bg-slate-50"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="p-2.5 rounded-2xl bg-primary-600 hover:bg-primary-700 text-white shadow-sm transition-all disabled:opacity-40"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
}
