import React, { useState, useEffect } from 'react';
import { 
  X, 
  CalendarCheck, 
  Clock, 
  BookOpen, 
  AlertCircle, 
  Calendar,
  Sparkles,
  BookCheck,
  Zap
} from 'lucide-react';
import { useTasks } from '../../context/TasksContext';
import { AVAILABLE_SUBJECTS } from '../../lib/mockData';

export default function TaskModal({ taskToEdit, onClose }) {
  const { addTask, updateTask } = useTasks();

  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState(AVAILABLE_SUBJECTS[0]);
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState('Medium');
  const [difficulty, setDifficulty] = useState('Medium'); // 'Easy' | 'Medium' | 'Hard'
  const [isTopic, setIsTopic] = useState(false); // boolean: Syllabus topic module tracker (+150 XP)
  const [deadline, setDeadline] = useState('');
  const [estimatedMinutes, setEstimatedMinutes] = useState(60);
  const [error, setError] = useState('');

  useEffect(() => {
    if (taskToEdit) {
      setTitle(taskToEdit.title || '');
      setSubject(taskToEdit.subject || AVAILABLE_SUBJECTS[0]);
      setDescription(taskToEdit.description || '');
      setPriority(taskToEdit.priority || 'Medium');
      setDifficulty(taskToEdit.difficulty || 'Medium');
      setIsTopic(Boolean(taskToEdit.is_topic));
      setDeadline(taskToEdit.deadline ? taskToEdit.deadline.slice(0, 16) : '');
      setEstimatedMinutes(taskToEdit.estimated_minutes || 60);
    } else {
      const tomorrow = new Date(Date.now() + 86400000);
      setDeadline(tomorrow.toISOString().slice(0, 16));
    }
  }, [taskToEdit]);

  const getExpectedXP = () => {
    if (isTopic) return 150;
    if (difficulty === 'Easy') return 25;
    if (difficulty === 'Hard') return 100;
    return 50;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Please provide a task or topic title.');
      return;
    }

    const payload = {
      title: title.trim(),
      subject,
      description: description.trim(),
      priority,
      difficulty,
      is_topic: isTopic,
      deadline: new Date(deadline).toISOString(),
      estimated_minutes: parseInt(estimatedMinutes, 10) || 60
    };

    if (taskToEdit) {
      updateTask(taskToEdit.id, payload);
    } else {
      addTask(payload);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6 animate-scale-in">
        
        {/* Header */}
        <div className="p-6 pb-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-primary-50 text-primary-600 flex items-center justify-center">
              <CalendarCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                {taskToEdit ? 'Edit Task / Topic' : 'Add Study Task or Topic'}
              </h2>
              <p className="text-xs text-slate-500">Plan deliverables & earn Study XP</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Type Selector: Daily Study Task vs Full Syllabus Module */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
            <span className="text-xs font-bold text-slate-800 block">Task Category:</span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setIsTopic(false)}
                className={`py-2 px-3 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 transition-all ${
                  !isTopic
                    ? 'bg-white text-primary-700 border-primary-500 shadow-xs ring-2 ring-primary-500/20'
                    : 'bg-slate-100/60 text-slate-600 border-transparent hover:bg-slate-100'
                }`}
              >
                <CalendarCheck className="w-3.5 h-3.5" />
                <span>Daily Study Task</span>
              </button>

              <button
                type="button"
                onClick={() => setIsTopic(true)}
                className={`py-2 px-3 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 transition-all ${
                  isTopic
                    ? 'bg-purple-600 text-white border-purple-600 shadow-xs'
                    : 'bg-slate-100/60 text-slate-600 border-transparent hover:bg-slate-100'
                }`}
              >
                <BookCheck className="w-3.5 h-3.5" />
                <span>Syllabus Topic (+150 XP)</span>
              </button>
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              {isTopic ? 'Syllabus Topic / Module Name *' : 'Task Title *'}
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={isTopic ? "e.g. Dynamic Programming & Memoization Patterns" : "e.g. Solve 3 LeetCode Graph Problems"}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 transition-all"
            />
          </div>

          {/* Difficulty & XP Reward indicator */}
          {!isTopic && (
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-slate-700">Difficulty Level</label>
                <span className="text-[11px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                  Earns +{getExpectedXP()} Study XP
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'Easy', label: 'Easy (+25 XP)', color: 'border-emerald-300 text-emerald-800' },
                  { id: 'Medium', label: 'Medium (+50 XP)', color: 'border-blue-300 text-blue-800' },
                  { id: 'Hard', label: 'Hard (+100 XP)', color: 'border-rose-300 text-rose-800' }
                ].map(diff => (
                  <button
                    key={diff.id}
                    type="button"
                    onClick={() => setDifficulty(diff.id)}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                      difficulty === diff.id
                        ? `${diff.color} bg-white shadow-xs ring-2 ring-primary-500/20`
                        : 'border-slate-200 bg-slate-50 text-slate-500 hover:bg-slate-100'
                    }`}
                  >
                    {diff.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Subject & Priority */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">Subject</label>
              <select
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500"
              >
                {AVAILABLE_SUBJECTS.map(s => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 font-medium"
              >
                <option value="Low">🟢 Low</option>
                <option value="Medium">🔵 Medium</option>
                <option value="High">🟠 High</option>
                <option value="Urgent">🔴 Urgent</option>
              </select>
            </div>
          </div>

          {/* Deadline */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">Deadline (Date & Time) *</label>
            <input
              type="datetime-local"
              required
              value={deadline}
              onChange={(e) => setDeadline(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">Notes & Syllabus Reference</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Key textbook chapters, problem numbers, or exam topics..."
              className="w-full p-3 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500"
            />
          </div>

          {/* XP Banner */}
          <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 flex items-center justify-between text-xs">
            <span className="flex items-center gap-1.5 font-bold text-amber-900">
              <Zap className="w-4 h-4 text-amber-600 fill-amber-500" />
              Completion Reward:
            </span>
            <span className="font-extrabold text-amber-700 text-sm">
              +{getExpectedXP()} Study XP
            </span>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-primary-600 hover:bg-primary-700 text-white font-bold text-xs shadow-md shadow-primary-500/20 transition-all hover:scale-[1.01]"
            >
              {taskToEdit ? 'Save Changes' : `Create & Earn +${getExpectedXP()} XP`}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}
