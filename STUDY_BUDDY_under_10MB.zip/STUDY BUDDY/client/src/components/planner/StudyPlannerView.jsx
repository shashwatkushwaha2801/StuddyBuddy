import React, { useState } from 'react';
import { 
  CalendarCheck, 
  Plus, 
  CheckCircle2, 
  Circle, 
  Clock, 
  AlertCircle, 
  Edit3, 
  Trash2, 
  Sparkles, 
  Filter, 
  CheckCheck,
  Flame,
  Award,
  Zap,
  BookCheck
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTasks } from '../../context/TasksContext';
import { AVAILABLE_SUBJECTS } from '../../lib/mockData';
import TaskModal from './TaskModal';
import PomodoroTimer from './PomodoroTimer';

export default function StudyPlannerView() {
  const { currentUser } = useAuth();
  const { 
    filteredTasks, 
    filterStatus, 
    setFilterStatus, 
    filterSubject, 
    setFilterSubject, 
    toggleTaskCompleted, 
    deleteTask, 
    metrics 
  } = useTasks();

  const [modalOpen, setModalOpen] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState(null);

  const getPriorityBadge = (p) => {
    switch (p) {
      case 'Urgent':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      case 'High':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'Medium':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      default:
        return 'bg-slate-100 text-slate-600 border-slate-200';
    }
  };

  const formatDeadline = (dateStr) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    const now = new Date();
    const diffHours = Math.round((date - now) / (1000 * 60 * 60));

    if (diffHours < 0) {
      return { text: `Overdue by ${Math.abs(diffHours)}h`, isOverdue: true };
    }
    if (diffHours <= 24) {
      return { text: `Due in ${diffHours}h`, isUrgent: true };
    }
    return { text: date.toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }), isUrgent: false };
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner & Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Left: Summary Banner & Metrics */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-soft flex flex-col justify-between">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
              <div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary-50 text-primary-700 text-xs font-semibold mb-2 border border-primary-100">
                  <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                  <span>Syllabus & XP Study Tracker</span>
                </div>
                <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
                  <CalendarCheck className="w-6 h-6 text-primary-600" />
                  Study Planner & Topic Tracker
                </h1>
                <p className="text-xs text-slate-500 mt-1">
                  Complete tasks (+25, +50, +100 XP) and syllabus modules (+150 XP) to rank up. Reverting completed tasks deducts XP to prevent cheating.
                </p>
              </div>

              <button
                onClick={() => {
                  setTaskToEdit(null);
                  setModalOpen(true);
                }}
                className="px-4 py-2.5 rounded-2xl bg-primary-600 hover:bg-primary-700 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-md shadow-primary-500/20 transition-all hover:scale-[1.02] flex-shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>Add Task / Topic</span>
              </button>
            </div>

            {/* Metrics Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-4">
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Total Tasks
                </span>
                <span className="text-2xl font-black text-slate-900">{metrics.total}</span>
              </div>

              <div className="p-3.5 rounded-2xl bg-emerald-50/50 border border-emerald-100">
                <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider block mb-1">
                  Completed
                </span>
                <span className="text-2xl font-black text-emerald-700">{metrics.completed}</span>
              </div>

              <div className="p-3.5 rounded-2xl bg-purple-50/50 border border-purple-100">
                <span className="text-[10px] font-bold text-purple-600 uppercase tracking-wider block mb-1">
                  Topics Mastered
                </span>
                <span className="text-2xl font-black text-purple-700">{metrics.completedTopics || 0}</span>
              </div>

              <div className="p-3.5 rounded-2xl bg-amber-50/50 border border-amber-100">
                <span className="text-[10px] font-bold text-amber-600 uppercase tracking-wider block mb-1">
                  XP Earned
                </span>
                <span className="text-2xl font-black text-amber-600">+{metrics.totalXPEarned} XP</span>
              </div>
            </div>
          </div>

          {/* Progress bar */}
          <div className="pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between text-xs text-slate-500 font-medium mb-1.5">
              <span>Completion Rate</span>
              <span className="font-bold text-slate-800">{metrics.completed} of {metrics.total} completed ({metrics.completionRate}%)</span>
            </div>
            <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-primary-500 to-emerald-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${metrics.completionRate}%` }}
              />
            </div>
          </div>
        </div>

        {/* Right: Embedded Focus Pomodoro */}
        <div className="lg:col-span-1">
          <PomodoroTimer />
        </div>

      </div>

      {/* Filter Tabs & Task List */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-soft space-y-4">
        
        {/* Filter Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          
          {/* Status Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {[
              { id: 'all', label: 'All Items' },
              { id: 'pending', label: 'Pending' },
              { id: 'completed', label: 'Completed' },
              { id: 'topics', label: '📖 Syllabus Topics (+150 XP)' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setFilterStatus(tab.id)}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap ${
                  filterStatus === tab.id
                    ? 'bg-primary-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Subject Filter Dropdown */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Subject:
            </span>
            <select
              value={filterSubject}
              onChange={(e) => setFilterSubject(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl border border-slate-200 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-primary-500/20 font-medium"
            >
              <option value="all">All Subjects</option>
              {AVAILABLE_SUBJECTS.map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

        </div>

        {/* Tasks List */}
        <div className="space-y-3">
          {filteredTasks.length === 0 ? (
            <div className="py-12 text-center text-slate-400">
              <CheckCheck className="w-12 h-12 text-slate-200 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-600">No tasks in this view!</p>
              <p className="text-xs text-slate-400 mt-0.5">Click "Add Task / Topic" above to organize your study plan.</p>
            </div>
          ) : (
            filteredTasks.map(task => {
              const deadlineInfo = formatDeadline(task.deadline);
              const xpAmount = task.xp_reward || (task.is_topic ? 150 : task.difficulty === 'Easy' ? 25 : task.difficulty === 'Hard' ? 100 : 50);

              return (
                <div
                  key={task.id}
                  className={`p-4 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                    task.completed
                      ? 'bg-slate-50/70 border-slate-200/60 opacity-80'
                      : task.is_topic
                      ? 'bg-purple-50/30 border-purple-200/80 shadow-2xs hover:border-purple-300'
                      : 'bg-white border-slate-200/80 shadow-2xs hover:border-primary-300'
                  }`}
                >
                  {/* Left: Checkbox & Details */}
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <button
                      onClick={() => toggleTaskCompleted(task.id)}
                      className="mt-0.5 text-slate-400 hover:text-primary-600 transition-colors flex-shrink-0"
                      title={task.completed ? "Uncheck to revert (deducts XP)" : `Mark complete (+${xpAmount} XP)`}
                    >
                      {task.completed ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-600 fill-emerald-100" />
                      ) : (
                        <Circle className="w-5 h-5 hover:text-primary-600" />
                      )}
                    </button>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span
                          className={`text-sm font-bold truncate ${
                            task.completed ? 'line-through text-slate-400' : 'text-slate-900'
                          }`}
                        >
                          {task.title}
                        </span>

                        {/* Syllabus topic indicator */}
                        {task.is_topic ? (
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-extrabold bg-purple-100 text-purple-800 border border-purple-200 flex items-center gap-1">
                            <BookCheck className="w-3 h-3" /> Syllabus Topic
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-slate-100 text-slate-700">
                            {task.subject}
                          </span>
                        )}

                        {/* Difficulty & XP Reward Tag */}
                        <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${
                          task.is_topic
                            ? 'bg-purple-50 text-purple-700 border-purple-200'
                            : task.difficulty === 'Hard'
                            ? 'bg-rose-50 text-rose-700 border-rose-200'
                            : task.difficulty === 'Easy'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : 'bg-blue-50 text-blue-700 border-blue-200'
                        }`}>
                          {task.is_topic ? '+150 XP' : `+${xpAmount} XP (${task.difficulty || 'Medium'})`}
                        </span>

                        <span
                          className={`px-2 py-0.5 rounded-md text-[10px] font-semibold border ${getPriorityBadge(
                            task.priority
                          )}`}
                        >
                          {task.priority}
                        </span>
                      </div>

                      {task.description && (
                        <p className="text-xs text-slate-500 mb-2 leading-relaxed">
                          {task.description}
                        </p>
                      )}

                      <div className="flex items-center gap-4 text-[11px] text-slate-400 font-medium">
                        <span
                          className={`flex items-center gap-1 ${
                            deadlineInfo.isOverdue && !task.completed
                              ? 'text-rose-600 font-bold'
                              : deadlineInfo.isUrgent && !task.completed
                              ? 'text-amber-600 font-bold'
                              : 'text-slate-500'
                          }`}
                        >
                          <Clock className="w-3.5 h-3.5" />
                          <span>{deadlineInfo.text}</span>
                        </span>

                        <span>•</span>

                        <span>{task.estimated_minutes || 60} mins</span>

                        {task.completed && (
                          <>
                            <span>•</span>
                            <span className="text-emerald-600 font-semibold flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" /> XP Credited
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Right: Edit & Delete buttons */}
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <button
                      onClick={() => {
                        setTaskToEdit(task);
                        setModalOpen(true);
                      }}
                      className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                      title="Edit Task"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => deleteTask(task.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      title="Delete Task"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

      </div>

      {/* Task Modal */}
      {modalOpen && (
        <TaskModal
          taskToEdit={taskToEdit}
          onClose={() => {
            setModalOpen(false);
            setTaskToEdit(null);
          }}
        />
      )}

    </div>
  );
}
