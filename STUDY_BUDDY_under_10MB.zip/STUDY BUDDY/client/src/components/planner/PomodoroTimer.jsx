import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Timer, Sparkles, Coffee } from 'lucide-react';

export default function PomodoroTimer() {
  const [mode, setMode] = useState('focus'); // 'focus' (25m) | 'shortBreak' (5m) | 'longBreak' (15m)
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    let timer = null;
    if (isRunning && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsRunning(false);
    }
    return () => clearInterval(timer);
  }, [isRunning, timeLeft]);

  const switchMode = (newMode, minutes) => {
    setMode(newMode);
    setTimeLeft(minutes * 60);
    setIsRunning(false);
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const progressPercent = mode === 'focus' 
    ? ((25 * 60 - timeLeft) / (25 * 60)) * 100
    : mode === 'shortBreak'
    ? ((5 * 60 - timeLeft) / (5 * 60)) * 100
    : ((15 * 60 - timeLeft) / (15 * 60)) * 100;

  return (
    <div className="bg-gradient-to-br from-indigo-900 to-primary-950 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden flex flex-col justify-between">
      
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-primary-300">
            <Timer className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">Focus Pomodoro</h3>
            <span className="text-[10px] text-slate-300">Deep study sprint</span>
          </div>
        </div>

        <div className="flex gap-1 bg-white/10 p-1 rounded-xl text-[11px] font-semibold">
          <button
            onClick={() => switchMode('focus', 25)}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              mode === 'focus' ? 'bg-primary-500 text-white shadow-xs' : 'text-slate-300 hover:text-white'
            }`}
          >
            25m Focus
          </button>
          <button
            onClick={() => switchMode('shortBreak', 5)}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              mode === 'shortBreak' ? 'bg-emerald-500 text-white shadow-xs' : 'text-slate-300 hover:text-white'
            }`}
          >
            5m Break
          </button>
        </div>
      </div>

      {/* Clock Display */}
      <div className="text-center my-4">
        <div className="text-5xl font-black tracking-tight font-mono text-white mb-2">
          {formattedTime}
        </div>
        <p className="text-xs text-slate-300 font-medium">
          {mode === 'focus' ? '🎯 Stay in deep focus flow' : '☕ Step away & rest your eyes'}
        </p>

        {/* Progress bar */}
        <div className="w-full bg-white/15 h-1.5 rounded-full mt-4 overflow-hidden">
          <div
            className={`h-full transition-all duration-300 ${
              mode === 'focus' ? 'bg-primary-400' : 'bg-emerald-400'
            }`}
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-3 mt-2">
        <button
          onClick={() => setIsRunning(!isRunning)}
          className="px-6 py-2.5 rounded-2xl bg-white text-primary-950 font-bold text-xs flex items-center gap-2 hover:bg-slate-100 transition-all shadow-md active:scale-95"
        >
          {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-primary-950" />}
          <span>{isRunning ? 'Pause' : 'Start Focus'}</span>
        </button>

        <button
          onClick={() => {
            setIsRunning(false);
            setTimeLeft(mode === 'focus' ? 25 * 60 : 5 * 60);
          }}
          className="p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white transition-all"
          title="Reset Timer"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
}
