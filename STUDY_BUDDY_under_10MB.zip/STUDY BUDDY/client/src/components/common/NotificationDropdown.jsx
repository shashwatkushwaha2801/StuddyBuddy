import React, { useState } from 'react';
import { Bell, UserPlus, Check, X, ArrowRight } from 'lucide-react';
import { useConnections } from '../../context/ConnectionsContext';

export default function NotificationDropdown({ onNavigateToConnections }) {
  const { receivedRequests, acceptRequest, rejectRequest } = useConnections();
  const [isOpen, setIsOpen] = useState(false);

  const count = receivedRequests.length;

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-all"
        aria-label="Notifications"
      >
        <Bell className="w-5 h-5" />
        {count > 0 && (
          <span className="absolute top-1.5 right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-primary-600 text-[10px] font-bold text-white ring-2 ring-white animate-pulse">
            {count}
          </span>
        )}
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 p-3 z-50 animate-scale-in">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 px-2">
            <span className="font-semibold text-xs text-slate-800 flex items-center gap-1.5">
              <UserPlus className="w-4 h-4 text-primary-600" />
              Connection Requests ({count})
            </span>
            {count > 0 && (
              <button
                onClick={() => {
                  setIsOpen(false);
                  onNavigateToConnections?.('received');
                }}
                className="text-[11px] text-primary-600 hover:text-primary-700 font-medium flex items-center gap-0.5"
              >
                View all <ArrowRight className="w-3 h-3" />
              </button>
            )}
          </div>

          {count === 0 ? (
            <div className="py-6 text-center text-slate-400 text-xs">
              <p>No new connection requests right now.</p>
              <p className="text-[11px] text-slate-400 mt-1">Explore matches to connect with peers!</p>
            </div>
          ) : (
            <div className="max-h-72 overflow-y-auto space-y-2 py-1">
              {receivedRequests.map(req => (
                <div key={req.id} className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 hover:border-slate-200 transition-all">
                  <div className="flex items-center gap-2.5 mb-1.5">
                    <img
                      src={req.student.avatar_url}
                      alt={req.student.full_name}
                      className="w-8 h-8 rounded-full object-cover border border-slate-200"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold text-slate-800 truncate">
                        {req.student.full_name}
                      </p>
                      <p className="text-[10px] text-slate-500 truncate">
                        {req.student.college} • {req.student.branch}
                      </p>
                    </div>
                  </div>
                  {req.message && (
                    <p className="text-[11px] text-slate-600 bg-white p-2 rounded-lg border border-slate-100 mb-2 italic">
                      "{req.message}"
                    </p>
                  )}
                  <div className="flex gap-2">
                    <button
                      onClick={() => acceptRequest(req.id)}
                      className="flex-1 py-1 px-2.5 rounded-lg bg-primary-600 hover:bg-primary-700 text-white text-xs font-medium flex items-center justify-center gap-1 shadow-sm transition-all"
                    >
                      <Check className="w-3.5 h-3.5" /> Accept
                    </button>
                    <button
                      onClick={() => rejectRequest(req.id)}
                      className="py-1 px-2.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-medium flex items-center justify-center gap-1 transition-all"
                    >
                      <X className="w-3.5 h-3.5" /> Decline
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
