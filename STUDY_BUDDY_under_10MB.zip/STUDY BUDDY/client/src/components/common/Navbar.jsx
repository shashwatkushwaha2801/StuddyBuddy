import React, { useState } from 'react';
import { 
  GraduationCap, 
  Users, 
  UserCheck, 
  CalendarCheck, 
  User, 
  LogOut, 
  Menu, 
  X, 
  LogIn, 
  Sparkles,
  Trophy,
  Flame,
  Award
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useConnections } from '../../context/ConnectionsContext';
import DemoBadge from './DemoBadge';
import PersonaSwitcher from './PersonaSwitcher';
import NotificationDropdown from './NotificationDropdown';
import RankBadge from './RankBadge';

export default function Navbar({ activeTab, setActiveTab }) {
  const { currentUser, logout, setAuthModalMode, currentRank } = useAuth();
  const { receivedRequests } = useConnections();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  const pendingCount = receivedRequests.length;

  const navItems = [
    { id: 'matches', label: 'Find Partners', icon: Sparkles },
    { 
      id: 'connections', 
      label: 'My Connections', 
      icon: UserCheck, 
      badge: pendingCount > 0 ? pendingCount : null 
    },
    { id: 'groups', label: 'Study Groups', icon: Users },
    { id: 'planner', label: 'Study Planner', icon: CalendarCheck },
    { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('matches')}
              className="flex items-center gap-2.5 group text-left focus:outline-none"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-primary-600 to-brand-600 flex items-center justify-center text-white shadow-md shadow-primary-500/20 group-hover:scale-105 transition-all">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <span className="font-extrabold text-lg tracking-tight text-slate-900 group-hover:text-primary-600 transition-colors flex items-center gap-1">
                  StudyBuddy
                  <span className="text-xs px-1.5 py-0.5 rounded-md bg-primary-100 text-primary-700 font-semibold tracking-normal">
                    v1.0
                  </span>
                </span>
                <span className="block text-[10px] text-slate-400 font-medium">Smart Student Collaboration</span>
              </div>
            </button>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`relative flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-primary-50 text-primary-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-primary-600' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className="ml-0.5 px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-primary-600 text-white">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Bar */}
          <div className="hidden md:flex items-center gap-2.5">
            <DemoBadge />
            <PersonaSwitcher />
            <NotificationDropdown onNavigateToConnections={() => setActiveTab('connections')} />

            {/* User Streak & Rank Badge in Navbar */}
            {currentUser && (
              <div className="flex items-center gap-2 border-l border-slate-200 pl-2.5">
                {/* Streak Counter */}
                <div 
                  onClick={() => setActiveTab('leaderboard')}
                  className="cursor-pointer flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-50 border border-amber-200 text-amber-700 text-xs font-bold hover:bg-amber-100 transition-colors"
                  title="Daily Study Streak"
                >
                  <Flame className="w-3.5 h-3.5 fill-amber-500 text-amber-600" />
                  <span>{currentUser.study_streak || 0}d</span>
                </div>

                {/* Free Fire Visual Rank Badge */}
                <div onClick={() => setActiveTab('profile')} className="cursor-pointer">
                  <RankBadge xp={currentUser.study_xp || 0} size="sm" variant="badge" />
                </div>
              </div>
            )}

            {/* Profile Dropdown or Auth Button */}
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                  className="flex items-center gap-2 p-1 pl-1.5 pr-2.5 rounded-full hover:bg-slate-100 border border-slate-200/80 transition-all"
                >
                  <img
                    src={currentUser.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentUser.full_name}`}
                    alt={currentUser.full_name}
                    className="w-7 h-7 rounded-full object-cover ring-2 ring-primary-500/20"
                  />
                  <span className="text-xs font-semibold text-slate-800 max-w-[90px] truncate">
                    {currentUser.full_name}
                  </span>
                </button>

                {profileDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-200 py-1.5 z-50 animate-scale-in">
                    <div className="px-4 py-3 border-b border-slate-100">
                      <p className="text-xs font-bold text-slate-900 truncate">{currentUser.full_name}</p>
                      <p className="text-[11px] text-slate-500 truncate">{currentUser.email}</p>
                      <p className="text-[10px] text-primary-600 font-medium mt-0.5">{currentUser.college}</p>
                      
                      <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between">
                        <RankBadge xp={currentUser.study_xp || 0} size="xs" variant="badge" />
                        <span className="text-[11px] font-bold text-primary-600">
                          {(currentUser.study_xp || 0).toLocaleString()} XP
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setActiveTab('profile');
                        setProfileDropdownOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 text-xs text-slate-700 hover:bg-slate-50 font-medium transition-colors"
                    >
                      <User className="w-4 h-4 text-slate-400" />
                      View & Edit Profile
                    </button>

                    <button
                      onClick={() => {
                        setActiveTab('leaderboard');
                        setProfileDropdownOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 text-xs text-slate-700 hover:bg-slate-50 font-medium transition-colors"
                    >
                      <Trophy className="w-4 h-4 text-amber-500" />
                      Global Leaderboard
                    </button>

                    <button
                      onClick={() => {
                        logout();
                        setProfileDropdownOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 text-xs text-rose-600 hover:bg-rose-50 font-medium transition-colors border-t border-slate-100"
                    >
                      <LogOut className="w-4 h-4 text-rose-500" />
                      Log Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setAuthModalMode('login')}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-all"
                >
                  Log In
                </button>
                <button
                  onClick={() => setAuthModalMode('register')}
                  className="px-3.5 py-1.5 text-xs font-semibold text-white bg-primary-600 hover:bg-primary-700 rounded-xl shadow-sm transition-all"
                >
                  Register
                </button>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="flex md:hidden items-center gap-2">
            <DemoBadge />
            <NotificationDropdown onNavigateToConnections={() => setActiveTab('connections')} />
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3">
          <div className="mb-2">
            <PersonaSwitcher />
          </div>

          {currentUser && (
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <img
                  src={currentUser.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentUser.full_name}`}
                  alt={currentUser.full_name}
                  className="w-8 h-8 rounded-full object-cover"
                />
                <div>
                  <span className="font-bold text-xs text-slate-800 block">{currentUser.full_name}</span>
                  <span className="text-[10px] text-slate-400">{currentUser.college}</span>
                </div>
              </div>
              <RankBadge xp={currentUser.study_xp || 0} size="sm" variant="badge" />
            </div>
          )}

          <div className="space-y-1">
            {navItems.map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-4 py-2.5 rounded-xl text-sm font-medium ${
                    isActive ? 'bg-primary-50 text-primary-700 font-bold' : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className="w-4 h-4 text-slate-500" />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-primary-600 text-white">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          <div className="pt-2 border-t border-slate-100">
            {currentUser ? (
              <div className="space-y-1">
                <button
                  onClick={() => {
                    setActiveTab('profile');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full flex items-center gap-3 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 rounded-xl"
                >
                  <User className="w-4 h-4" />
                  <span>My Profile</span>
                </button>
                <button
                  onClick={() => {
                    logout();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full flex items-center gap-3 px-4 py-2 text-sm text-rose-600 hover:bg-rose-50 rounded-xl"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Log Out</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  onClick={() => {
                    setAuthModalMode('login');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-2 text-xs font-semibold text-slate-700 border border-slate-200 rounded-xl"
                >
                  Log In
                </button>
                <button
                  onClick={() => {
                    setAuthModalMode('register');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-2 text-xs font-semibold text-white bg-primary-600 rounded-xl"
                >
                  Register
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
