import React from 'react';
import { 
  Shield, 
  ShieldCheck, 
  Award, 
  Zap, 
  Gem, 
  Flame, 
  Crown,
  Sparkles
} from 'lucide-react';
import { getRankFromXP } from '../../lib/rankSystem';

export default function RankBadge({ 
  xp = 0, 
  size = 'md', // 'xs' | 'sm' | 'md' | 'lg' | 'xl'
  variant = 'badge', // 'badge' | 'pill' | 'detailed' | 'iconOnly'
  className = '',
  showXP = false
}) {
  const rank = getRankFromXP(xp);

  // Choose appropriate icon for tier
  const renderIcon = (iconSizeClass = 'w-3.5 h-3.5') => {
    switch (rank.color) {
      case 'grandmaster':
        return <Crown className={`${iconSizeClass} text-amber-200 fill-amber-200 animate-pulse`} />;
      case 'heroic':
        return <Flame className={`${iconSizeClass} text-rose-200 fill-rose-200`} />;
      case 'diamond':
        return <Gem className={`${iconSizeClass} text-purple-200 fill-purple-200`} />;
      case 'platinum':
        return <Zap className={`${iconSizeClass} text-cyan-200 fill-cyan-200`} />;
      case 'gold':
        return <Award className={`${iconSizeClass} text-amber-900 fill-amber-900`} />;
      case 'silver':
        return <ShieldCheck className={`${iconSizeClass} text-slate-100 fill-slate-200`} />;
      case 'bronze':
      default:
        return <Shield className={`${iconSizeClass} text-amber-200 fill-amber-300`} />;
    }
  };

  // Size configurations
  const sizeConfig = {
    xs: {
      pill: 'px-1.5 py-0.5 text-[10px] gap-1',
      icon: 'w-2.5 h-2.5',
      badge: 'px-2 py-0.5 text-[10px] gap-1'
    },
    sm: {
      pill: 'px-2 py-0.5 text-[11px] gap-1.5',
      icon: 'w-3 h-3',
      badge: 'px-2.5 py-0.5 text-[11px] gap-1.5'
    },
    md: {
      pill: 'px-3 py-1 text-xs gap-1.5',
      icon: 'w-3.5 h-3.5',
      badge: 'px-3 py-1 text-xs gap-2'
    },
    lg: {
      pill: 'px-4 py-1.5 text-sm gap-2',
      icon: 'w-4 h-4',
      badge: 'px-4 py-1.5 text-sm gap-2.5 font-bold'
    },
    xl: {
      pill: 'px-5 py-2 text-base gap-2.5',
      icon: 'w-5 h-5',
      badge: 'px-6 py-2.5 text-base gap-3 font-extrabold'
    }
  }[size] || { pill: 'px-3 py-1 text-xs gap-1.5', icon: 'w-3.5 h-3.5', badge: 'px-3 py-1 text-xs gap-2' };

  if (variant === 'iconOnly') {
    return (
      <div 
        className={`inline-flex items-center justify-center rounded-lg ${rank.theme.bgBadge} p-1.5 shadow-sm text-white ${className}`}
        title={`${rank.fullName} (${rank.xp.toLocaleString()} XP)`}
      >
        {renderIcon(sizeConfig.icon)}
      </div>
    );
  }

  if (variant === 'pill') {
    return (
      <span 
        className={`inline-flex items-center rounded-full font-semibold border ${rank.theme.pillBg} ${sizeConfig.pill} transition-all ${className}`}
      >
        {renderIcon(sizeConfig.icon)}
        <span>{rank.fullName}</span>
        {showXP && (
          <span className="opacity-75 text-[10px]">({rank.xp.toLocaleString()} XP)</span>
        )}
      </span>
    );
  }

  if (variant === 'detailed') {
    return (
      <div className={`flex items-center gap-3 p-3 rounded-2xl bg-white border border-slate-200 shadow-sm ${className}`}>
        <div className={`w-12 h-12 rounded-2xl ${rank.theme.bgBadge} flex items-center justify-center shadow-md flex-shrink-0 text-white ${rank.color === 'grandmaster' ? 'ring-2 ring-amber-400 ring-offset-2' : ''}`}>
          {renderIcon('w-6 h-6')}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <span className="font-extrabold text-sm text-slate-900 tracking-tight flex items-center gap-1.5">
              {rank.fullName}
              {rank.isMaxRank && <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-spin" />}
            </span>
            <span className="text-xs font-semibold text-primary-600 bg-primary-50 px-2 py-0.5 rounded-full">
              {rank.xp.toLocaleString()} XP
            </span>
          </div>
          <div className="mt-1.5">
            <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
              <span>{rank.isMaxRank ? 'Peak Tier Reached' : `Next: ${rank.nextRank?.fullName}`}</span>
              <span>{rank.isMaxRank ? 'MAX' : `${rank.xpNeededForNext} XP left`}</span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
              <div 
                className={`h-full ${rank.theme.bgBadge} transition-all duration-500 rounded-full`}
                style={{ width: `${rank.isMaxRank ? 100 : rank.progressPercent}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Default 'badge' style: Metallic / Gem Gradient Badge
  return (
    <span 
      className={`inline-flex items-center font-bold rounded-xl ${rank.theme.bgBadge} ${rank.theme.textBadge} shadow-sm ${rank.theme.glow} border ${rank.theme.border} ${sizeConfig.badge} select-none transition-all hover:scale-105 ${className}`}
      title={`${rank.fullName} • ${rank.xp.toLocaleString()} XP`}
    >
      {renderIcon(sizeConfig.icon)}
      <span className="tracking-tight">{rank.fullName}</span>
      {showXP && (
        <span className="text-[10px] opacity-80 font-normal ml-0.5">
          {rank.xp.toLocaleString()} XP
        </span>
      )}
    </span>
  );
}
