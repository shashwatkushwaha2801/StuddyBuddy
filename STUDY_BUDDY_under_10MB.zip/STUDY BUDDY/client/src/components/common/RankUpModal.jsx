import React, { useEffect } from 'react';
import { 
  Trophy, 
  Sparkles, 
  X, 
  ArrowRight, 
  Flame, 
  CheckCircle2, 
  Share2,
  Crown
} from 'lucide-react';
import confetti from 'canvas-confetti';
import RankBadge from './RankBadge';

export default function RankUpModal({ rankUpData, onClose }) {
  if (!rankUpData) return null;

  const { previousRank, newRank, tierChanged } = rankUpData;

  useEffect(() => {
    // Fire double celebration confetti bursts
    try {
      const end = Date.now() + 1500;
      const colors = ['#6366F1', '#EC4899', '#F59E0B', '#10B981', '#3B82F6'];

      (function frame() {
        confetti({
          particleCount: 4,
          angle: 60,
          spread: 55,
          origin: { x: 0, y: 0.65 },
          colors
        });
        confetti({
          particleCount: 4,
          angle: 120,
          spread: 55,
          origin: { x: 1, y: 0.65 },
          colors
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      })();
    } catch (e) {
      console.warn('Confetti error:', e);
    }
  }, [rankUpData]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden text-center animate-scale-in">
        
        {/* Glowing Banner / Aura */}
        <div className={`p-8 ${newRank.theme.bgBadge} text-white relative overflow-hidden`}>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(255,255,255,0.3),transparent_70%)]" />
          
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-black/20 hover:bg-black/30 text-white transition-all"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="relative z-10 flex flex-col items-center">
            <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center shadow-lg mb-3 border border-white/30 animate-bounce">
              <Trophy className="w-9 h-9 text-yellow-300 drop-shadow-md" />
            </div>

            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-[11px] font-bold tracking-wider uppercase mb-1">
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              <span>Rank Promoted!</span>
            </div>

            <h2 className="text-2xl font-black tracking-tight drop-shadow-sm">
              {tierChanged ? `Entered ${newRank.tier} Tier!` : `Promoted to ${newRank.fullName}!`}
            </h2>
            <p className="text-xs text-white/80 mt-1">
              Your consistent study grind and completed topics paid off.
            </p>
          </div>
        </div>

        {/* Rank Progression Comparison */}
        <div className="p-6">
          <div className="flex items-center justify-center gap-4 py-4 px-3 bg-slate-50 rounded-2xl border border-slate-100 mb-6">
            <div className="text-center">
              <span className="text-[10px] text-slate-400 font-semibold uppercase block mb-1">Previous</span>
              <RankBadge xp={previousRank.xp} size="sm" variant="pill" />
            </div>

            <ArrowRight className="w-5 h-5 text-slate-400 flex-shrink-0 animate-pulse" />

            <div className="text-center">
              <span className="text-[10px] text-emerald-600 font-semibold uppercase block mb-1">New Rank</span>
              <RankBadge xp={newRank.xp} size="md" variant="badge" />
            </div>
          </div>

          {/* Perks unlocked */}
          <div className="space-y-2 text-left mb-6">
            <div className="flex items-center gap-2.5 text-xs text-slate-700 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
              <span>Higher visibility on the <strong>Study Partner Matchmaker</strong></span>
            </div>
            <div className="flex items-center gap-2.5 text-xs text-slate-700 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
              <span>Climbed the <strong>College & Global Leaderboards</strong></span>
            </div>
            <div className="flex items-center gap-2.5 text-xs text-slate-700 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
              <span>Unlocked the metallic <strong>{newRank.fullName}</strong> badge on profile</span>
            </div>
          </div>

          {/* Action button */}
          <button
            onClick={onClose}
            className={`w-full py-3 rounded-2xl font-bold text-sm text-white shadow-lg transition-all hover:scale-[1.02] ${newRank.theme.bgBadge}`}
          >
            Claim Rewards & Continue
          </button>
        </div>

      </div>
    </div>
  );
}
