import React from 'react';
import { GraduationCap, Trophy } from 'lucide-react';

export default function Footer({ onNavigate }) {
  return (
    <footer className="mt-16 border-t border-slate-200/80 bg-white/70 backdrop-blur-xs py-8 text-xs text-slate-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-primary-600 flex items-center justify-center text-white">
              <GraduationCap className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-slate-900">StudyBuddy</span>
              <span className="text-slate-400 ml-1.5">— Smart Student Collaboration & Gamified Learning</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-6 font-medium text-slate-600">
            <button onClick={() => onNavigate('matches')} className="hover:text-primary-600 transition-colors">
              Find Partners
            </button>
            <button onClick={() => onNavigate('connections')} className="hover:text-primary-600 transition-colors">
              Connections
            </button>
            <button onClick={() => onNavigate('groups')} className="hover:text-primary-600 transition-colors">
              Study Groups
            </button>
            <button onClick={() => onNavigate('planner')} className="hover:text-primary-600 transition-colors">
              Study Planner
            </button>
            <button onClick={() => onNavigate('leaderboard')} className="hover:text-primary-600 transition-colors flex items-center gap-1 font-semibold text-amber-600">
              <Trophy className="w-3.5 h-3.5" />
              Leaderboard
            </button>
          </div>

          <div className="text-center sm:text-right text-[11px] text-slate-400">
            <span>Free Fire Ranks • 50% Subjects • 25% Timing • 25% Goals</span>
          </div>

        </div>
      </div>
    </footer>
  );
}
