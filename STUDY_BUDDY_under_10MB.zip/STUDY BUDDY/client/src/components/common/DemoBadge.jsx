import React, { useState } from 'react';
import { Database, Zap, HelpCircle, CheckCircle2, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export default function DemoBadge() {
  const { isSupabaseConfigured } = useAuth();
  const [showTooltip, setShowTooltip] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setShowTooltip(!showTooltip)}
        className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border transition-all ${
          isSupabaseConfigured
            ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
            : 'bg-violet-50 text-violet-700 border-violet-200 hover:bg-violet-100'
        }`}
        title="Database status"
      >
        {isSupabaseConfigured ? (
          <>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <Database className="w-3.5 h-3.5" />
            <span>Supabase Live</span>
          </>
        ) : (
          <>
            <Zap className="w-3.5 h-3.5 text-violet-600 fill-violet-600" />
            <span>Active Demo Mode</span>
          </>
        )}
      </button>

      {showTooltip && (
        <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-200 p-4 z-50 animate-scale-in text-xs text-slate-600">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100">
            <span className="font-semibold text-slate-800 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-primary-600" />
              Database Architecture
            </span>
            <button
              onClick={() => setShowTooltip(false)}
              className="text-slate-400 hover:text-slate-600 font-bold"
            >
              ✕
            </button>
          </div>
          {isSupabaseConfigured ? (
            <div className="space-y-2">
              <p className="text-emerald-700 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Connected to Supabase PostgreSQL
              </p>
              <p>All profiles, connection requests, and groups sync directly with your PostgreSQL database instance.</p>
            </div>
          ) : (
            <div className="space-y-2">
              <p className="text-violet-700 font-semibold flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-violet-600" />
                Full Functional Local Mode
              </p>
              <p className="text-slate-600 leading-relaxed">
                StudyBuddy is running with real-time persistent data in your browser and backend. All features—including the weighted 50%/25%/25% partner matching algorithm, connection requests, study groups, and task planner—are 100% interactive!
              </p>
              <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500">
                To connect Supabase: Set <code className="bg-slate-100 px-1 py-0.5 rounded text-primary-700">VITE_SUPABASE_URL</code> and <code className="bg-slate-100 px-1 py-0.5 rounded text-primary-700">VITE_SUPABASE_ANON_KEY</code> in <code className="bg-slate-100 px-1 py-0.5 rounded text-primary-700">.env</code>.
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
