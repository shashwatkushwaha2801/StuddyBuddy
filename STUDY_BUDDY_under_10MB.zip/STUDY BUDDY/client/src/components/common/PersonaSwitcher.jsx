import React, { useState } from 'react';
import { UserCheck, ChevronDown, Check, Sparkles } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import RankBadge from './RankBadge';

export default function PersonaSwitcher() {
  const { currentUser, allProfiles, switchPersona } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 border border-slate-200 text-xs font-medium text-slate-700 transition-all"
        title="Switch student to test matchmaking from different perspectives"
      >
        <Sparkles className="w-3.5 h-3.5 text-primary-600" />
        <span className="hidden sm:inline text-slate-500">Testing as:</span>
        <span className="font-semibold text-slate-900 max-w-[110px] truncate">
          {currentUser ? currentUser.full_name : 'Guest'}
        </span>
        <ChevronDown className="w-3 h-3 text-slate-400" />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-72 bg-white rounded-2xl shadow-2xl border border-slate-200 p-2 z-50 animate-scale-in">
          <div className="px-3 py-2 border-b border-slate-100">
            <p className="text-xs font-bold text-slate-800">Switch Student Persona</p>
            <p className="text-[11px] text-slate-500">
              Instantly test how matching and requests look from other students' perspectives.
            </p>
          </div>

          <div className="max-h-60 overflow-y-auto py-1 divide-y divide-slate-50">
            {allProfiles.map(student => {
              const isActive = currentUser?.id === student.id;
              return (
                <button
                  key={student.id}
                  onClick={() => {
                    switchPersona(student.id);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 text-left rounded-xl transition-all ${
                    isActive ? 'bg-primary-50 text-primary-900' : 'hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img
                      src={student.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${student.full_name}`}
                      alt={student.full_name}
                      className="w-7 h-7 rounded-full object-cover border border-slate-200 flex-shrink-0"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <p className="text-xs font-semibold text-slate-800 truncate">
                          {student.full_name}
                        </p>
                        <RankBadge xp={student.study_xp || 0} size="xs" variant="badge" />
                      </div>
                      <p className="text-[10px] text-slate-500 truncate">
                        {student.branch} • {student.year}
                      </p>
                    </div>
                  </div>
                  {isActive && <Check className="w-4 h-4 text-primary-600 flex-shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
