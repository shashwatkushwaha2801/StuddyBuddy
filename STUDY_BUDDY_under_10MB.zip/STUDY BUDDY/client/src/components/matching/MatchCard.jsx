import React, { useState } from 'react';
import { 
  School, 
  BookOpen, 
  Calendar, 
  Clock, 
  Sparkles, 
  UserPlus, 
  UserCheck, 
  Clock4, 
  Eye, 
  Send,
  HelpCircle,
  MessageSquare
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useConnections } from '../../context/ConnectionsContext';
import RankBadge from '../common/RankBadge';

export default function MatchCard({ 
  student, 
  onViewProfile, 
  onViewBreakdown 
}) {
  const { currentUser } = useAuth();
  const { getConnectionStatus, sendRequest, cancelByStudentId } = useConnections();
  const [showNote, setShowNote] = useState(false);
  const [note, setNote] = useState('');

  if (!student || (currentUser && student.id === currentUser.id)) {
    return null; // Do not recommend logged-in student to themselves
  }

  const compatibility = student.compatibility || {
    score: 0,
    commonSubjects: [],
    timingMatchStatus: 'None'
  };

  const status = getConnectionStatus(student.id);

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-emerald-700 bg-emerald-50 border-emerald-200 ring-emerald-500/20';
    if (score >= 60) return 'text-primary-700 bg-primary-50 border-primary-200 ring-primary-500/20';
    return 'text-amber-700 bg-amber-50 border-amber-200 ring-amber-500/20';
  };

  const handleSend = () => {
    sendRequest(student.id, note);
    setShowNote(false);
    setNote('');
  };

  return (
    <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-soft hover:shadow-elevated transition-all duration-200 flex flex-col justify-between group relative">
      
      {/* Top row: Avatar + Name + Compatibility Score Badge */}
      <div>
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="relative flex-shrink-0">
              <img
                src={student.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${student.full_name}`}
                alt={student.full_name}
                className="w-13 h-13 rounded-2xl object-cover border border-slate-200 shadow-xs group-hover:scale-105 transition-transform"
              />
              <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white" title="Active"></span>
            </div>
            
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <h3 className="text-base font-bold text-slate-900 group-hover:text-primary-600 transition-colors truncate">
                  {student.full_name}
                </h3>
                <RankBadge xp={student.study_xp || 0} size="xs" variant="badge" />
              </div>
              <p className="text-xs text-slate-500 flex items-center gap-1 truncate mt-0.5">
                <School className="w-3 h-3 text-slate-400 flex-shrink-0" />
                <span className="truncate">{student.college || 'University'}</span>
              </p>
              <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5 truncate">
                <BookOpen className="w-3 h-3 text-slate-400 flex-shrink-0" />
                <span className="truncate">{student.branch || 'General'}</span>
                <span>•</span>
                <span>{student.year || 'Student'}</span>
              </p>
            </div>
          </div>

          {/* Compatibility Percentage Pill & Breakdown Trigger */}
          <button
            onClick={() => onViewBreakdown(student)}
            className={`flex-shrink-0 px-2.5 py-1.5 rounded-2xl border text-xs font-extrabold flex items-center gap-1.5 transition-transform hover:scale-105 shadow-2xs ${getScoreColor(compatibility.score)}`}
            title="Click to see 50%/25%/25% compatibility breakdown"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{compatibility.score}%</span>
          </button>
        </div>

        {/* Bio quote if available */}
        {student.bio && (
          <p className="text-xs text-slate-600 line-clamp-2 italic mb-3 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
            "{student.bio}"
          </p>
        )}

        {/* Common Subjects (50% factor) */}
        <div className="mb-3">
          <div className="flex items-center justify-between text-[11px] text-slate-500 font-semibold mb-1">
            <span className="flex items-center gap-1 text-slate-700">
              <BookOpen className="w-3 h-3 text-primary-600" />
              Common Subjects:
            </span>
            <span className="text-[10px] text-primary-600 font-medium">50% Weight</span>
          </div>

          <div className="flex flex-wrap gap-1 min-h-[28px]">
            {compatibility.commonSubjects && compatibility.commonSubjects.length > 0 ? (
              compatibility.commonSubjects.map(sub => (
                <span
                  key={sub}
                  className="px-2 py-0.5 rounded-lg text-xs font-semibold bg-primary-50 text-primary-700 border border-primary-200/80"
                >
                  ✓ {sub}
                </span>
              ))
            ) : (
              <span className="text-xs text-slate-400 italic">
                {student.subjects?.slice(0, 2).join(', ') || 'No overlapping subjects yet'}
              </span>
            )}
          </div>
        </div>

        {/* Preferred Study Time (25% factor) */}
        <div className="mb-4 flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-100 text-xs">
          <div className="flex items-center gap-1.5 text-slate-600 font-medium">
            <Clock className="w-3.5 h-3.5 text-emerald-600" />
            <span>Preferred Timing:</span>
          </div>
          <span className="font-semibold text-slate-800 text-right">
            {student.study_timing || 'Flexible'}
          </span>
        </div>
      </div>

      {/* Action Footer */}
      <div className="pt-3 border-t border-slate-100">
        {showNote ? (
          <div className="space-y-2">
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder={`Hi ${student.full_name.split(' ')[0]}! Let's study together...`}
              rows={2}
              className="w-full p-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500"
            />
            <div className="flex gap-2">
              <button
                onClick={handleSend}
                className="flex-1 py-1.5 rounded-xl bg-primary-600 hover:bg-primary-700 text-white text-xs font-semibold flex items-center justify-center gap-1 shadow-xs transition-all"
              >
                <Send className="w-3 h-3" /> Send
              </button>
              <button
                onClick={() => setShowNote(false)}
                className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-semibold"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            
            {/* View Profile Button */}
            <button
              onClick={() => onViewProfile(student)}
              className="flex-1 py-2 px-3 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
            >
              <Eye className="w-3.5 h-3.5 text-slate-400" />
              <span>View Profile</span>
            </button>

            {/* Connection Request Button States */}
            {status === 'accepted' ? (
              <span className="py-2 px-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-semibold flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5" />
                <span>Connected</span>
              </span>
            ) : status === 'pending_sent' ? (
              <button
                onClick={() => cancelByStudentId(student.id)}
                className="py-2 px-3 rounded-xl bg-amber-50 hover:bg-rose-50 border border-amber-200 hover:border-rose-200 text-amber-700 hover:text-rose-700 text-xs font-semibold flex items-center gap-1.5 transition-colors group/btn"
                title="Click to cancel pending request"
              >
                <Clock4 className="w-3.5 h-3.5 text-amber-600 group-hover/btn:hidden" />
                <span className="group-hover/btn:hidden">Requested</span>
                <span className="hidden group-hover/btn:inline">Cancel</span>
              </button>
            ) : (
              <button
                onClick={() => setShowNote(true)}
                className="py-2 px-3.5 rounded-xl bg-primary-600 hover:bg-primary-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-sm shadow-primary-500/20 transition-all hover:scale-[1.02]"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Connect</span>
              </button>
            )}

          </div>
        )}
      </div>

    </div>
  );
}
