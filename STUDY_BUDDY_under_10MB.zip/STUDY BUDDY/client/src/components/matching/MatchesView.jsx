import React, { useState, useMemo } from 'react';
import { Sparkles, Users, SlidersHorizontal, BookOpen, Clock, Target, ArrowUpDown, Info } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { rankStudyPartners } from '../../lib/matchingAlgorithm';
import MatchCard from './MatchCard';
import FilterBar from './FilterBar';
import MatchScoreBreakdownModal from './MatchScoreBreakdownModal';
import StudentProfileModal from './StudentProfileModal';

export default function MatchesView() {
  const { currentUser, allProfiles } = useAuth();

  const [filters, setFilters] = useState({
    search: '',
    subject: 'all',
    timing: 'all',
    year: 'all',
    minScore: 0
  });

  const [selectedStudentForProfile, setSelectedStudentForProfile] = useState(null);
  const [selectedStudentForBreakdown, setSelectedStudentForBreakdown] = useState(null);

  // Execute recommendation algorithm across all registered student profiles
  const rankedPartners = useMemo(() => {
    if (!currentUser) return [];
    return rankStudyPartners(currentUser, allProfiles, filters);
  }, [currentUser, allProfiles, filters]);

  return (
    <div className="space-y-6">
      
      {/* Hero Recommendation Header */}
      <div className="bg-gradient-to-r from-primary-900 via-indigo-900 to-brand-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        {/* Subtle decorative glow */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-primary-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-xs font-semibold text-primary-200 mb-3 border border-white/10">
            <Sparkles className="w-3.5 h-3.5 text-primary-400" />
            <span>Weighted Match Engine Active</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2">
            Smart Study Partner Recommendations
          </h1>

          <p className="text-sm text-slate-300 leading-relaxed mb-4">
            StudyBuddy matches you with peers using a weighted compatibility formula based on your registered academic profile:
          </p>

          {/* Formula weight chips */}
          <div className="flex flex-wrap gap-2 text-xs">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 border border-white/10 text-white font-medium">
              <BookOpen className="w-4 h-4 text-primary-300" />
              <span>Common Subjects: <strong>50%</strong></span>
            </div>

            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 border border-white/10 text-white font-medium">
              <Clock className="w-4 h-4 text-emerald-300" />
              <span>Study Timings: <strong>25%</strong></span>
            </div>

            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 border border-white/10 text-white font-medium">
              <Target className="w-4 h-4 text-purple-300" />
              <span>Learning Goals: <strong>25%</strong></span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <FilterBar
        filters={filters}
        setFilters={setFilters}
        totalMatches={rankedPartners.length}
      />

      {/* Results Header */}
      <div className="flex items-center justify-between text-xs font-semibold text-slate-500 px-1">
        <div className="flex items-center gap-2 text-slate-700">
          <Users className="w-4 h-4 text-primary-600" />
          <span>Found <strong>{rankedPartners.length}</strong> compatible study partners</span>
        </div>
        <div className="flex items-center gap-1 text-slate-400">
          <ArrowUpDown className="w-3.5 h-3.5" />
          <span>Sorted by compatibility (highest first)</span>
        </div>
      </div>

      {/* Cards Grid */}
      {rankedPartners.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {rankedPartners.map(student => (
            <MatchCard
              key={student.id}
              student={student}
              onViewProfile={(std) => setSelectedStudentForProfile(std)}
              onViewBreakdown={(std) => setSelectedStudentForBreakdown(std)}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200/80 shadow-soft">
          <div className="w-16 h-16 rounded-2xl bg-primary-50 text-primary-600 flex items-center justify-center mx-auto mb-3">
            <Users className="w-8 h-8" />
          </div>
          <h3 className="text-base font-bold text-slate-800 mb-1">No Study Partners Found</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto mb-4">
            We couldn't find students matching your current filter criteria. Try relaxing your filters or lowering the minimum compatibility score.
          </p>
          <button
            onClick={() => setFilters({ search: '', subject: 'all', timing: 'all', year: 'all', minScore: 0 })}
            className="px-4 py-2 rounded-xl bg-primary-600 text-white font-semibold text-xs hover:bg-primary-700 transition-all shadow-sm"
          >
            Clear All Filters
          </button>
        </div>
      )}

      {/* Modals */}
      {selectedStudentForProfile && (
        <StudentProfileModal
          student={selectedStudentForProfile}
          currentUser={currentUser}
          onClose={() => setSelectedStudentForProfile(null)}
          onOpenBreakdown={(std) => {
            setSelectedStudentForBreakdown(std);
          }}
        />
      )}

      {selectedStudentForBreakdown && (
        <MatchScoreBreakdownModal
          candidate={selectedStudentForBreakdown}
          currentUser={currentUser}
          onClose={() => setSelectedStudentForBreakdown(null)}
        />
      )}

    </div>
  );
}
