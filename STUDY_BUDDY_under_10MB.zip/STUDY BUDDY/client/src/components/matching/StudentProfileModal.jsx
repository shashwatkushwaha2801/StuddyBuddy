import React, { useState } from 'react';
import { 
  X, 
  School, 
  BookOpen, 
  Calendar, 
  Clock, 
  Target, 
  Award, 
  Send, 
  UserCheck, 
  Clock4, 
  Sparkles,
  MessageSquare
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useConnections } from '../../context/ConnectionsContext';
import RankBadge from '../common/RankBadge';
import { Flame } from 'lucide-react';

export default function StudentProfileModal({ student, onClose, onOpenBreakdown }) {
  const { currentUser } = useAuth();
  const { getConnectionStatus, sendRequest, cancelByStudentId } = useConnections();

  const [customMessage, setCustomMessage] = useState('');
  const [showNoteInput, setShowNoteInput] = useState(false);
  const [requestStatus, setRequestStatus] = useState('');

  if (!student) return null;

  const status = getConnectionStatus(student.id);

  const handleSend = () => {
    const res = sendRequest(student.id, customMessage);
    if (res.success) {
      setRequestStatus('Request Sent!');
      setShowNoteInput(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6 animate-scale-in">
        
        {/* Cover / Header Accent */}
        <div className="h-28 bg-gradient-to-r from-primary-600 via-brand-600 to-indigo-700 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-black/20 hover:bg-black/40 text-white flex items-center justify-center transition-all backdrop-blur-xs"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Profile Card Header */}
        <div className="px-6 pb-4 relative">
          <div className="flex justify-between items-end -mt-12 mb-3">
            <div className="relative">
              <img
                src={student.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${student.full_name}`}
                alt={student.full_name}
                className="w-24 h-24 rounded-2xl object-cover border-4 border-white shadow-lg bg-white"
              />
              <span className="absolute bottom-1 right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-white" title="Active"></span>
            </div>

            {student.compatibility && (
              <button
                onClick={() => onOpenBreakdown?.(student)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-primary-50 hover:bg-primary-100 border border-primary-200 text-xs font-bold text-primary-700 transition-all shadow-xs"
                title="View Compatibility Score Breakdown"
              >
                <Sparkles className="w-4 h-4 text-primary-600" />
                <span>{student.compatibility.score}% Match</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-xl font-bold text-slate-900">{student.full_name}</h2>
            <RankBadge xp={student.study_xp || 0} size="sm" variant="badge" />
          </div>
          
          <div className="flex flex-wrap items-center gap-y-1 gap-x-3 text-xs text-slate-600 mt-1">
            <span className="flex items-center gap-1 font-medium text-slate-800">
              <School className="w-3.5 h-3.5 text-primary-600" />
              {student.college}
            </span>
            <span>•</span>
            <span className="flex items-center gap-1 font-medium">
              <BookOpen className="w-3.5 h-3.5 text-slate-400" />
              {student.branch}
            </span>
            <span>•</span>
            <span className="flex items-center gap-1 font-medium text-slate-500">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              {student.year}
            </span>
            <span>•</span>
            <span className="flex items-center gap-1 font-bold text-amber-600">
              <Flame className="w-3.5 h-3.5 fill-amber-500" />
              {student.study_streak || 0}d streak
            </span>
          </div>
        </div>

        {/* Details Content */}
        <div className="px-6 pb-6 space-y-4 max-h-[60vh] overflow-y-auto">
          
          {/* Bio */}
          {student.bio && (
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100 text-xs text-slate-700 leading-relaxed italic">
              "{student.bio}"
            </div>
          )}

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-2 gap-2.5">
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1 mb-1">
                <Clock className="w-3 h-3 text-emerald-500" />
                Study Timing
              </span>
              <p className="text-xs font-semibold text-slate-800">
                {student.study_timing || 'Flexible'}
              </p>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1 mb-1">
                <Award className="w-3 h-3 text-amber-500" />
                Current Skill Level
              </span>
              <p className="text-xs font-semibold text-slate-800">
                {student.skill_level || 'Intermediate'}
              </p>
            </div>
          </div>

          {/* Subjects of Interest */}
          <div>
            <span className="text-xs font-bold text-slate-800 block mb-2 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-primary-600" />
              Subjects of Interest:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {(student.subjects || []).map(subject => {
                const isShared = (currentUser?.subjects || []).some(
                  s => s.toLowerCase() === subject.toLowerCase()
                );
                return (
                  <span
                    key={subject}
                    className={`px-2.5 py-1 rounded-xl text-xs font-medium border transition-all ${
                      isShared
                        ? 'bg-primary-50 text-primary-700 border-primary-200 font-semibold ring-1 ring-primary-500/10'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    {isShared && '✓ '}
                    {subject}
                  </span>
                );
              })}
            </div>
          </div>

          {/* Learning Goals */}
          <div>
            <span className="text-xs font-bold text-slate-800 block mb-2 flex items-center gap-1.5">
              <Target className="w-3.5 h-3.5 text-brand-600" />
              Learning Goals:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {(student.learning_goals || []).map(goal => (
                <span
                  key={goal}
                  className="px-2.5 py-1 rounded-xl text-xs font-medium bg-purple-50 text-purple-700 border border-purple-100"
                >
                  🎯 {goal}
                </span>
              ))}
            </div>
          </div>

          {/* Connection Action Section */}
          <div className="pt-3 border-t border-slate-100">
            {status === 'accepted' ? (
              <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-semibold">
                  <UserCheck className="w-4 h-4 text-emerald-600" />
                  <span>You are connected Study Buddies!</span>
                </div>
              </div>
            ) : status === 'pending_sent' ? (
              <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 text-amber-800 flex items-center justify-between text-xs">
                <span className="flex items-center gap-2 font-medium">
                  <Clock4 className="w-4 h-4 text-amber-600" />
                  Connection Request Pending
                </span>
                <button
                  onClick={() => cancelByStudentId(student.id)}
                  className="text-xs font-semibold text-rose-600 hover:text-rose-700 underline"
                >
                  Cancel Request
                </button>
              </div>
            ) : status === 'self' ? (
              <p className="text-center text-xs text-slate-400 italic">This is your own profile</p>
            ) : (
              <div className="space-y-2">
                {showNoteInput ? (
                  <div className="space-y-2">
                    <textarea
                      value={customMessage}
                      onChange={(e) => setCustomMessage(e.target.value)}
                      placeholder={`Hi ${student.full_name.split(' ')[0]}! Would love to study together...`}
                      rows={2}
                      className="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500"
                    />
                    <div className="flex gap-2">
                      <button
                        onClick={handleSend}
                        className="flex-1 py-2.5 rounded-xl bg-primary-600 hover:bg-primary-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all"
                      >
                        <Send className="w-3.5 h-3.5" /> Send Request Now
                      </button>
                      <button
                        onClick={() => setShowNoteInput(false)}
                        className="px-3 py-2.5 rounded-xl bg-slate-100 text-slate-600 font-semibold text-xs"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <button
                      onClick={handleSend}
                      className="flex-1 py-2.5 rounded-xl bg-primary-600 hover:bg-primary-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-primary-500/20 transition-all"
                    >
                      <Send className="w-3.5 h-3.5" /> Send Connection Request
                    </button>
                    <button
                      onClick={() => setShowNoteInput(true)}
                      className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium transition-all"
                      title="Add a custom study note"
                    >
                      <MessageSquare className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}
