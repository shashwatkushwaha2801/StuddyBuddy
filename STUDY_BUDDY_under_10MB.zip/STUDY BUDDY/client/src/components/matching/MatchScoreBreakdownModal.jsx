import React from 'react';
import { X, Sparkles, BookOpen, Clock, Target, CheckCircle2, Info } from 'lucide-react';

export default function MatchScoreBreakdownModal({ candidate, currentUser, onClose }) {
  if (!candidate || !currentUser) return null;

  const { compatibility } = candidate;
  const { score, subjectScore, timingScore, goalScore, commonSubjects, commonGoals, timingMatchStatus } = compatibility;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden animate-scale-in">
        
        {/* Header */}
        <div className="p-6 pb-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-primary-50 text-primary-600 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Compatibility Formula</h3>
              <p className="text-xs text-slate-500">
                Between you & <span className="text-slate-700 font-semibold">{candidate.full_name}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          
          {/* Total Score Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-primary-500 to-brand-600 text-white flex items-center justify-between shadow-md shadow-primary-500/20">
            <div>
              <span className="text-xs font-medium text-white/80 block">Weighted Compatibility</span>
              <span className="text-3xl font-extrabold tracking-tight">{score}%</span>
            </div>
            <div className="text-right text-xs text-white/90">
              <span className="px-2.5 py-1 rounded-full bg-white/20 font-semibold backdrop-blur-xs">
                {score >= 80 ? 'Highly Compatible 🔥' : score >= 60 ? 'Strong Match ⭐' : 'Potential Partner 💡'}
              </span>
            </div>
          </div>

          {/* Breakdown Items */}
          <div className="space-y-3">
            
            {/* 1. Common Subjects (50%) */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/70">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">Common Academic Subjects</h4>
                    <span className="text-[10px] text-slate-500">Weighted at 50%</span>
                  </div>
                </div>
                <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-200">
                  {subjectScore} / 50 pts
                </span>
              </div>

              {commonSubjects.length > 0 ? (
                <div className="mt-2">
                  <span className="text-[11px] text-slate-500 block mb-1">Shared Subjects ({commonSubjects.length}):</span>
                  <div className="flex flex-wrap gap-1">
                    {commonSubjects.map(sub => (
                      <span key={sub} className="px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 text-[11px] font-medium border border-indigo-100">
                        ✓ {sub}
                      </span>
                    ))}
                  </div>
                </div>
              ) : (
                <p className="text-[11px] text-slate-500 mt-1">No directly overlapping subjects selected yet.</p>
              )}
            </div>

            {/* 2. Compatible Study Timings (25%) */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/70">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">Preferred Study Timings</h4>
                    <span className="text-[10px] text-slate-500">Weighted at 25%</span>
                  </div>
                </div>
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                  {timingScore} / 25 pts
                </span>
              </div>
              <div className="text-[11px] text-slate-600 mt-2 space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Your timing:</span>
                  <span className="font-semibold">{currentUser.study_timing || 'Flexible'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Candidate timing:</span>
                  <span className="font-semibold">{candidate.study_timing || 'Flexible'}</span>
                </div>
                <div className="pt-1 border-t border-slate-200 flex justify-between text-emerald-700 font-medium">
                  <span>Match Status:</span>
                  <span>{timingMatchStatus}</span>
                </div>
              </div>
            </div>

            {/* 3. Similar Learning Goals (25%) */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/70">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center">
                    <Target className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">Learning Goals & Ambitions</h4>
                    <span className="text-[10px] text-slate-500">Weighted at 25%</span>
                  </div>
                </div>
                <span className="text-xs font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md border border-purple-200">
                  {goalScore} / 25 pts
                </span>
              </div>

              {commonGoals.length > 0 ? (
                <div className="mt-2">
                  <span className="text-[11px] text-slate-500 block mb-1">Aligned Goals ({commonGoals.length}):</span>
                  <div className="flex flex-wrap gap-1">
                    {commonGoals.map(goal => (
                      <span key={goal} className="px-2 py-0.5 rounded-md bg-purple-50 text-purple-700 text-[11px] font-medium border border-purple-100">
                        🎯 {goal}
                      </span>
                    ))}
                  </div>
                </div>
              ) : (
                <p className="text-[11px] text-slate-500 mt-1">Different primary goals (e.g. Exam prep vs Project building).</p>
              )}
            </div>

          </div>

          {/* Mathematical Proof Note */}
          <div className="p-3 rounded-xl bg-primary-50/50 border border-primary-100 text-[11px] text-primary-900 leading-relaxed flex items-start gap-2">
            <Info className="w-4 h-4 text-primary-600 flex-shrink-0 mt-0.5" />
            <span>
              <strong>Formula specification:</strong> Score = 50% (Shared Subjects Overlap) + 25% (Study Time Compatibility) + 25% (Goal Alignment). Total capped at 100%.
            </span>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-all shadow-xs"
          >
            Close Breakdown
          </button>
        </div>

      </div>
    </div>
  );
}
