import React from 'react';
import { Search, Filter, RotateCcw, SlidersHorizontal, BookOpen, Clock, Calendar } from 'lucide-react';
import { AVAILABLE_SUBJECTS, STUDY_TIMINGS } from '../../lib/mockData';

export default function FilterBar({ filters, setFilters, totalMatches }) {
  const handleReset = () => {
    setFilters({
      search: '',
      subject: 'all',
      timing: 'all',
      year: 'all',
      minScore: 0
    });
  };

  const hasActiveFilters = 
    Boolean(filters.search) || 
    filters.subject !== 'all' || 
    filters.timing !== 'all' || 
    filters.year !== 'all' || 
    filters.minScore > 0;

  return (
    <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-soft space-y-4 mb-6">
      
      {/* Top Search & Filter Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
        
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={filters.search}
            onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
            placeholder="Search by student name, college, branch, or subject..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 transition-all bg-slate-50/50"
          />
        </div>

        {/* Quick Dropdown: Subject */}
        <div className="w-full md:w-56">
          <div className="relative">
            <BookOpen className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <select
              value={filters.subject}
              onChange={(e) => setFilters(prev => ({ ...prev, subject: e.target.value }))}
              className="w-full pl-9 pr-8 py-2 rounded-2xl border border-slate-200 text-xs font-medium text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 transition-all"
            >
              <option value="all">All Subjects</option>
              {AVAILABLE_SUBJECTS.map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Quick Dropdown: Timing */}
        <div className="w-full md:w-52">
          <div className="relative">
            <Clock className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <select
              value={filters.timing}
              onChange={(e) => setFilters(prev => ({ ...prev, timing: e.target.value }))}
              className="w-full pl-9 pr-8 py-2 rounded-2xl border border-slate-200 text-xs font-medium text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 transition-all"
            >
              <option value="all">All Timings</option>
              {STUDY_TIMINGS.map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>
        </div>

      </div>

      {/* Second Row: Year, Min Compatibility Slider & Status */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-3 border-t border-slate-100 text-xs">
        
        {/* Year Filter Buttons */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-slate-400 font-medium mr-1 flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5" /> Year:
          </span>
          {['all', '1st Year', '2nd Year', '3rd Year', '4th Year'].map(yr => (
            <button
              key={yr}
              onClick={() => setFilters(prev => ({ ...prev, year: yr }))}
              className={`px-2.5 py-1 rounded-xl text-xs font-semibold transition-all ${
                filters.year === yr
                  ? 'bg-primary-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {yr === 'all' ? 'All Years' : yr}
            </button>
          ))}
        </div>

        {/* Min Compatibility Slider & Reset */}
        <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end">
          <div className="flex items-center gap-2">
            <span className="text-slate-500 font-medium">Min Compatibility:</span>
            <input
              type="range"
              min="0"
              max="90"
              step="5"
              value={filters.minScore}
              onChange={(e) => setFilters(prev => ({ ...prev, minScore: Number(e.target.value) }))}
              className="w-24 accent-primary-600"
            />
            <span className="font-bold text-primary-700 bg-primary-50 px-2 py-0.5 rounded-md min-w-[36px] text-center border border-primary-100">
              {filters.minScore}%
            </span>
          </div>

          {hasActiveFilters && (
            <button
              onClick={handleReset}
              className="flex items-center gap-1 text-slate-500 hover:text-slate-800 font-semibold text-xs px-2 py-1 rounded-lg hover:bg-slate-100 transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              Reset
            </button>
          )}
        </div>

      </div>

    </div>
  );
}
