-- ====================================================================
-- StudyBuddy Seed Data (PostgreSQL for Supabase)
-- ====================================================================

-- 1. Insert Initial Student Profiles with Diverse Ranks (Bronze through Grandmaster)
INSERT INTO public.profiles (
    id, email, full_name, avatar_url, college, branch, year, subjects,
    skill_level, learning_goals, study_timing, bio, study_xp, study_streak, topics_completed, rank_tier, rank_name
) VALUES 
(
    '00000000-0000-0000-0000-000000000001',
    'alex.chen@stanford.edu',
    'Alex Chen',
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    'Stanford University',
    'Computer Science',
    '3rd Year',
    ARRAY['Data Structures', 'Algorithms', 'Machine Learning', 'Computer Networks'],
    'Advanced',
    ARRAY['Exam Prep', 'Competitive Programming', 'Side Projects'],
    'Evening (5PM - 9PM)',
    'Junior CS student passionate about distributed systems and competitive programming. Looking for a dedicated peer to grind LeetCode Medium/Hard patterns.',
    2480, 14, 18, 'Diamond', 'Diamond II'
),
(
    '00000000-0000-0000-0000-000000000002',
    'sophia.patel@berkeley.edu',
    'Sophia Patel',
    'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
    'UC Berkeley',
    'Data Science & AI',
    '3rd Year',
    ARRAY['Machine Learning', 'Data Structures', 'Linear Algebra', 'Probability & Statistics'],
    'Intermediate',
    ARRAY['Exam Prep', 'Side Projects', 'Research Paper Reading'],
    'Evening (5PM - 9PM)',
    'Exploring neural architectures, LLM fine-tuning, and statistical modeling. Big fan of 50/10 Pomodoro sprints.',
    3650, 22, 28, 'Heroic', 'Heroic'
),
(
    '00000000-0000-0000-0000-000000000003',
    'david.kim@stanford.edu',
    'David Kim',
    'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
    'Stanford University',
    'Computer Science',
    '4th Year',
    ARRAY['Data Structures', 'Operating Systems', 'System Design', 'Web Development'],
    'Advanced',
    ARRAY['Competitive Programming', 'Side Projects', 'Interview Prep'],
    'Late Night (9PM - 1AM)',
    'Senior undergrad preparing for tech company mock interviews. Always up for system design debates and late-night coding sessions.',
    4850, 35, 42, 'Grandmaster', 'Grandmaster'
),
(
    '00000000-0000-0000-0000-000000000004',
    'elena.gomez@gatech.edu',
    'Elena Gomez',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    'Georgia Tech',
    'Physics & Engineering',
    '2nd Year',
    ARRAY['Classical Mechanics', 'Electromagnetism', 'Calculus III', 'Thermodynamics'],
    'Intermediate',
    ARRAY['Exam Prep', 'Coursework Mastery', 'Lab Assignments'],
    'Afternoon (12PM - 4PM)',
    'Hands-on learner who loves connecting theoretical physics equations to real engineering scenarios.',
    1620, 11, 15, 'Platinum', 'Platinum II'
),
(
    '00000000-0000-0000-0000-000000000005',
    'marcus.vance@mit.edu',
    'Marcus Vance',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    'MIT',
    'Mathematics',
    '2nd Year',
    ARRAY['Calculus III', 'Linear Algebra', 'Discrete Mathematics', 'Probability & Statistics'],
    'Advanced',
    ARRAY['Exam Prep', 'Coursework Mastery'],
    'Morning (6AM - 10AM)',
    'Pure math enthusiast. I enjoy dissecting complex analysis proofs and vector calculus.',
    1080, 9, 12, 'Gold', 'Gold III'
),
(
    '00000000-0000-0000-0000-000000000006',
    'jordan.taylor@utexas.edu',
    'Jordan Taylor',
    'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
    'UT Austin',
    'Computer Science',
    '1st Year',
    ARRAY['Intro to Programming', 'Discrete Mathematics', 'Calculus I', 'Web Development'],
    'Beginner',
    ARRAY['Coursework Mastery', 'Side Projects', 'Exam Prep'],
    'Flexible',
    'Freshman coder excited to build interactive web apps with React. Enthusiastic, friendly, and always eager to learn from peers.',
    140, 3, 2, 'Bronze', 'Bronze II'
)
ON CONFLICT (id) DO NOTHING;

-- 2. Insert Popular Seed Study Groups
INSERT INTO public.study_groups (id, name, subject, description, visibility, max_members, schedule, tags)
VALUES
(
    '10000000-0000-0000-0000-000000000001',
    'Programming Pals',
    'Computer Science',
    'Weekly collaborative programming sessions focusing on algorithm visualization, code reviews, and debugging complex homework assignments.',
    'public', 50, 'Mondays & Thursdays, 7:00 PM EST', ARRAY['Algorithms', 'Python', 'C++', 'LeetCode']
),
(
    '10000000-0000-0000-0000-000000000002',
    'Mathematics Circle',
    'Mathematics',
    'A study forum dedicated to mastering proof techniques, Linear Algebra transformations, and Multivariable Calculus problem sets.',
    'public', 30, 'Tuesdays & Fridays, 10:00 AM EST', ARRAY['Calculus III', 'Linear Algebra', 'Discrete Math']
),
(
    '10000000-0000-0000-0000-000000000003',
    'Physics Forum',
    'Physics',
    'Deep dive into theoretical and applied physics. We dissect mechanics, electromagnetism formulas, thermodynamics, and lab experiments.',
    'public', 25, 'Wednesdays & Saturdays, 4:00 PM EST', ARRAY['Mechanics', 'Electromagnetism', 'Lab Prep']
),
(
    '10000000-0000-0000-0000-000000000004',
    'Data Structures Club',
    'Data Structures',
    'High-intensity practice group tackling tree traversals, dynamic programming, graphs, and Big-O efficiency analysis for interviews and midterms.',
    'public', 60, 'Daily, 8:30 PM EST', ARRAY['Binary Trees', 'Graphs', 'DP', 'System Design']
)
ON CONFLICT (id) DO NOTHING;
