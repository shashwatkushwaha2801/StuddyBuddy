-- ====================================================================
-- StudyBuddy Database Schema (PostgreSQL for Supabase)
-- Smart Student Collaboration & Gamified Learning Platform
-- ====================================================================

-- 1. Profiles Table (extends Supabase auth.users or standalone for demo)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    avatar_url TEXT,
    college TEXT NOT NULL,
    branch TEXT NOT NULL,
    year TEXT NOT NULL,
    subjects TEXT[] DEFAULT '{}',
    skill_level TEXT DEFAULT 'Intermediate',
    learning_goals TEXT[] DEFAULT '{}',
    study_timing TEXT DEFAULT 'Evening (5PM - 9PM)',
    bio TEXT,
    study_xp INT DEFAULT 0,
    study_streak INT DEFAULT 1,
    topics_completed INT DEFAULT 0,
    rank_tier TEXT DEFAULT 'Bronze',
    rank_name TEXT DEFAULT 'Bronze I',
    last_streak_claim DATE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public profiles are viewable by everyone" 
ON public.profiles FOR SELECT USING (true);

CREATE POLICY "Users can insert their own profile" 
ON public.profiles FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can update their own profile" 
ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- 2. Connection Requests Table
CREATE TABLE IF NOT EXISTS public.connection_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sender_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    receiver_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    status TEXT NOT NULL CHECK (status IN ('pending', 'accepted', 'rejected', 'canceled')) DEFAULT 'pending',
    message TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT prevent_self_request CHECK (sender_id <> receiver_id)
);

CREATE INDEX IF NOT EXISTS idx_conn_sender ON public.connection_requests(sender_id);
CREATE INDEX IF NOT EXISTS idx_conn_receiver ON public.connection_requests(receiver_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_pending_req ON public.connection_requests(sender_id, receiver_id) WHERE status = 'pending';

ALTER TABLE public.connection_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view connections involving them" 
ON public.connection_requests FOR SELECT USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "Users can insert requests" 
ON public.connection_requests FOR INSERT WITH CHECK (auth.uid() = sender_id);

CREATE POLICY "Users can update requests involving them" 
ON public.connection_requests FOR UPDATE USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

-- 3. Study Groups Table
CREATE TABLE IF NOT EXISTS public.study_groups (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    subject TEXT NOT NULL,
    description TEXT,
    visibility TEXT NOT NULL CHECK (visibility IN ('public', 'private')) DEFAULT 'public',
    created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    max_members INT DEFAULT 50,
    schedule TEXT,
    tags TEXT[] DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.study_groups ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Groups viewable by authenticated users" 
ON public.study_groups FOR SELECT USING (true);

CREATE POLICY "Users can create groups" 
ON public.study_groups FOR INSERT WITH CHECK (true);

CREATE POLICY "Creators can update their groups"
ON public.study_groups FOR UPDATE USING (auth.uid() = created_by);

-- 4. Group Members Table
CREATE TABLE IF NOT EXISTS public.group_members (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    group_id UUID NOT NULL REFERENCES public.study_groups(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    role TEXT DEFAULT 'member' CHECK (role IN ('admin', 'member')),
    joined_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (group_id, user_id)
);

ALTER TABLE public.group_members ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Group members are viewable by everyone" 
ON public.group_members FOR SELECT USING (true);

CREATE POLICY "Users can join groups" 
ON public.group_members FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can leave groups" 
ON public.group_members FOR DELETE USING (auth.uid() = user_id);

-- 5. Study Tasks & Topic Tracker Table
CREATE TABLE IF NOT EXISTS public.study_tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    subject TEXT,
    description TEXT,
    priority TEXT DEFAULT 'Medium' CHECK (priority IN ('Low', 'Medium', 'High', 'Urgent')),
    difficulty TEXT DEFAULT 'Medium' CHECK (difficulty IN ('Easy', 'Medium', 'Hard')),
    is_topic BOOLEAN DEFAULT FALSE,
    xp_reward INT DEFAULT 50,
    deadline TIMESTAMPTZ,
    estimated_minutes INT DEFAULT 60,
    completed BOOLEAN DEFAULT FALSE,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.study_tasks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view and manage their own tasks" 
ON public.study_tasks FOR ALL USING (auth.uid() = user_id);

-- 6. Study XP Logs & Anti-Cheat Audit Table
CREATE TABLE IF NOT EXISTS public.xp_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    action TEXT NOT NULL,
    reason TEXT,
    amount INT NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('gain', 'deduct')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.xp_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own XP logs" 
ON public.xp_logs FOR SELECT USING (auth.uid() = user_id);

-- 7. Direct Messages Table
CREATE TABLE IF NOT EXISTS public.messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sender_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    receiver_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view messages they sent or received" 
ON public.messages FOR SELECT USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "Users can send messages" 
ON public.messages FOR INSERT WITH CHECK (auth.uid() = sender_id);

-- Helper Function: Update Study XP & Rank Function
CREATE OR REPLACE FUNCTION public.update_student_xp(
    p_user_id UUID,
    p_amount INT,
    p_action TEXT,
    p_reason TEXT,
    p_is_deduct BOOLEAN DEFAULT FALSE
)
RETURNS JSON AS $$
DECLARE
    v_old_xp INT;
    v_new_xp INT;
    v_new_tier TEXT;
    v_new_name TEXT;
BEGIN
    SELECT study_xp INTO v_old_xp FROM public.profiles WHERE id = p_user_id;
    IF v_old_xp IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Profile not found');
    END IF;

    IF p_is_deduct THEN
        v_new_xp := GREATEST(0, v_old_xp - p_amount);
    ELSE
        v_new_xp := v_old_xp + p_amount;
    END IF;

    -- Calculate rank name based on Free Fire style thresholds
    IF v_new_xp >= 4500 THEN
        v_new_tier := 'Grandmaster';
        v_new_name := 'Grandmaster';
    ELSIF v_new_xp >= 3200 THEN
        v_new_tier := 'Heroic';
        v_new_name := 'Heroic';
    ELSIF v_new_xp >= 2920 THEN
        v_new_tier := 'Diamond';
        v_new_name := 'Diamond IV';
    ELSIF v_new_xp >= 2640 THEN
        v_new_tier := 'Diamond';
        v_new_name := 'Diamond III';
    ELSIF v_new_xp >= 2370 THEN
        v_new_tier := 'Diamond';
        v_new_name := 'Diamond II';
    ELSIF v_new_xp >= 2100 THEN
        v_new_tier := 'Diamond';
        v_new_name := 'Diamond I';
    ELSIF v_new_xp >= 1900 THEN
        v_new_tier := 'Platinum';
        v_new_name := 'Platinum IV';
    ELSIF v_new_xp >= 1700 THEN
        v_new_tier := 'Platinum';
        v_new_name := 'Platinum III';
    ELSIF v_new_xp >= 1500 THEN
        v_new_tier := 'Platinum';
        v_new_name := 'Platinum II';
    ELSIF v_new_xp >= 1300 THEN
        v_new_tier := 'Platinum';
        v_new_name := 'Platinum I';
    ELSIF v_new_xp >= 1150 THEN
        v_new_tier := 'Gold';
        v_new_name := 'Gold IV';
    ELSIF v_new_xp >= 1000 THEN
        v_new_tier := 'Gold';
        v_new_name := 'Gold III';
    ELSIF v_new_xp >= 850 THEN
        v_new_tier := 'Gold';
        v_new_name := 'Gold II';
    ELSIF v_new_xp >= 700 THEN
        v_new_tier := 'Gold';
        v_new_name := 'Gold I';
    ELSIF v_new_xp >= 560 THEN
        v_new_tier := 'Silver';
        v_new_name := 'Silver III';
    ELSIF v_new_xp >= 430 THEN
        v_new_tier := 'Silver';
        v_new_name := 'Silver II';
    ELSIF v_new_xp >= 300 THEN
        v_new_tier := 'Silver';
        v_new_name := 'Silver I';
    ELSIF v_new_xp >= 200 THEN
        v_new_tier := 'Bronze';
        v_new_name := 'Bronze III';
    ELSIF v_new_xp >= 100 THEN
        v_new_tier := 'Bronze';
        v_new_name := 'Bronze II';
    ELSE
        v_new_tier := 'Bronze';
        v_new_name := 'Bronze I';
    END IF;

    UPDATE public.profiles
    SET study_xp = v_new_xp,
        rank_tier = v_new_tier,
        rank_name = v_new_name,
        updated_at = NOW()
    WHERE id = p_user_id;

    INSERT INTO public.xp_logs (user_id, action, reason, amount, type)
    VALUES (p_user_id, p_action, p_reason, p_amount, CASE WHEN p_is_deduct THEN 'deduct' ELSE 'gain' END);

    RETURN json_build_object(
        'success', true,
        'old_xp', v_old_xp,
        'new_xp', v_new_xp,
        'tier', v_new_tier,
        'rank_name', v_new_name
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
